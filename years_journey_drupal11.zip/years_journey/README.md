# Years Journey - Drupal 11 Paragraph Component

This custom module creates a reusable "Our Journey So Far" component using:

- Journey Timeline Paragraph
- Nested Journey Timeline Item Paragraph
- Year field
- Unlimited milestone values

## Installation

Copy this directory into:

web/modules/custom/years_journey

Then enable the module:

drush en years_journey -y

Import configuration:

drush cim -y

Clear caches:

drush cr

If this is a new custom module and its configuration is being installed for the first time, enabling the module will install the config in config/install automatically. Do not run `drush cim` blindly on a site with unrelated configuration changes; use your normal configuration-management workflow.

## Paragraph structure

Journey Timeline
  - Journey Timeline Items (unlimited)

Journey Timeline Item
  - Year
  - Milestones (unlimited)

## Adding the component

Create a "Journey Timeline" paragraph and add as many "Journey Timeline Item" children as required.

Example:

2025
  - Upgraded Healthcare Facilities

2022
  - Mentorship Program
  - Group Farming Competition
  - Sports for Unity Initiative

2021
  - Cybage Sampada
  - Farmer Producer Company
  - Alumni Wing
  - Cybage Covid Sanjivani

2018
  - Rural Digitalization Drive
  - Water Conservation Projects

2017
  - Skill Development Centers

2014
  - Educational Support Expansion

2009
  - Community Outreach Launch

2005
  - Foundation Establishment

## Important

The original HTML had a fixed 3 cards per page. This Drupal implementation preserves 3 cards on desktop, 2 below 900px, and 1 below 600px while calculating pagination dynamically.

The JavaScript is scoped to each component instance, so multiple Journey Timeline paragraphs can safely appear on the same page.
