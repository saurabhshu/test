/**
 * @file
 * Behavior for the Years Journey Paragraph component.
 */

(function (Drupal, once) {
  'use strict';

  Drupal.behaviors.yearsJourney = {
    attach(context) {
      once('years-journey', '[data-journey-timeline]', context).forEach((component) => {
        const track = component.querySelector('[data-carousel-track]');
        const cards = Array.from(component.querySelectorAll('[data-journey-card]'));
        const nodes = Array.from(component.querySelectorAll('.timeline-node'));
        const dotsContainer = component.querySelector('[data-dots-indicator]');
        const prevBtn = component.querySelector('[data-prev]');
        const nextBtn = component.querySelector('[data-next]');

        if (!track || !cards.length || !dotsContainer) {
          return;
        }

        const getItemsPerPage = () => {
          if (window.matchMedia('(max-width: 600px)').matches) {
            return 1;
          }
          if (window.matchMedia('(max-width: 900px)').matches) {
            return 2;
          }
          return 3;
        };

        let currentPage = 0;

        const getTotalPages = () => Math.ceil(cards.length / getItemsPerPage());

        const getStepWidth = () => {
          const cardWidth = cards[0].getBoundingClientRect().width;
          const styles = window.getComputedStyle(track);
          const gap = parseFloat(styles.columnGap || styles.gap || 0);
          return (cardWidth + gap) * getItemsPerPage();
        };

        const updateTimeline = (page) => {
          nodes.forEach((node) => {
            const nodePage = parseInt(node.dataset.page, 10);
            const active = nodePage === page;
            node.classList.toggle('active', active);
            node.setAttribute('aria-pressed', active ? 'true' : 'false');
          });
        };

        const updateDots = (page) => {
          Array.from(dotsContainer.children).forEach((dot, index) => {
            const active = index === page;
            dot.classList.toggle('active', active);
            dot.setAttribute('aria-current', active ? 'page' : 'false');
          });
        };

        const updateButtons = () => {
          const totalPages = getTotalPages();
          prevBtn.disabled = currentPage === 0;
          nextBtn.disabled = currentPage >= totalPages - 1;
        };

        const updateView = (page) => {
          const totalPages = getTotalPages();

          if (page < 0 || page >= totalPages) {
            return;
          }

          currentPage = page;
          updateTimeline(page);
          updateDots(page);
          updateButtons();
        };

        const buildDots = () => {
          dotsContainer.innerHTML = '';
          const totalPages = getTotalPages();

          for (let i = 0; i < totalPages; i++) {
            const dot = document.createElement('button');
            dot.type = 'button';
            dot.className = 'dot' + (i === 0 ? ' active' : '');
            dot.dataset.page = String(i);
            dot.setAttribute('aria-label', Drupal.t('Go to page @page', {'@page': i + 1}));
            dot.setAttribute('aria-current', i === 0 ? 'page' : 'false');

            dot.addEventListener('click', () => {
              goToPage(i);
            });

            dotsContainer.appendChild(dot);
          }
        };

        const goToPage = (page) => {
          const totalPages = getTotalPages();

          if (page < 0 || page >= totalPages) {
            return;
          }

          track.scrollTo({
            left: page * getStepWidth(),
            behavior: 'smooth'
          });

          updateView(page);
        };

        const setNodePages = () => {
          const itemsPerPage = getItemsPerPage();

          nodes.forEach((node, index) => {
            node.dataset.page = String(Math.floor(index / itemsPerPage));
          });
        };

        prevBtn.addEventListener('click', () => goToPage(currentPage - 1));
        nextBtn.addEventListener('click', () => goToPage(currentPage + 1));

        nodes.forEach((node) => {
          node.addEventListener('click', () => {
            goToPage(parseInt(node.dataset.page, 10));
          });
        });

        let scrollTimeout;

        track.addEventListener('scroll', () => {
          window.clearTimeout(scrollTimeout);

          scrollTimeout = window.setTimeout(() => {
            const stepWidth = getStepWidth();

            if (!stepWidth) {
              return;
            }

            const page = Math.round(track.scrollLeft / stepWidth);
            const totalPages = getTotalPages();

            if (page !== currentPage && page >= 0 && page < totalPages) {
              updateView(page);
            }
          }, 50);
        }, {passive: true});

        let resizeTimeout;

        window.addEventListener('resize', () => {
          window.clearTimeout(resizeTimeout);

          resizeTimeout = window.setTimeout(() => {
            setNodePages();
            buildDots();

            const totalPages = getTotalPages();
            currentPage = Math.min(currentPage, totalPages - 1);

            track.scrollTo({
              left: currentPage * getStepWidth(),
              behavior: 'auto'
            });

            updateView(currentPage);
          }, 150);
        });

        setNodePages();
        buildDots();
        updateView(0);
      });
    }
  };

})(Drupal, once);
