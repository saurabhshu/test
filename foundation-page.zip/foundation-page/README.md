# Cybage Foundation page — sections 4–8

This folder documents how the **Cybage Foundation** page (node 301, content
type `page`) gets its custom sections, plus what to deploy to the Pantheon
server.

The "Our Impact" section uses two **new paragraph types** (`impact` with nested
`impact_item` children) that this folder defines as importable config. The other
sections reuse existing paragraph types styled via the theme.

## How each new section is built

| # | Section | Paragraph used | Layout | Raw design |
|---|---------|----------------|--------|------------|
| 4 | Our Journey So Far | `title_cards` + `cards` (existing, `foundation-journey`) | carousel | `rawhtml/our-journey-carousel.html` |
| 5 | Our Activities | `title_cards` + `cards` (existing, `foundation-activities`) | accordion | `rawhtml/our-activities-poc.html` |
| 6 | Our Impact | **`impact` + nested `impact_item` (new)** | before/after slider | `rawhtml/foundationdesign.html` |
| 7 | Overview stats | `add_stats` (enhanced: `field_stats_display`/`field_stats_layout`) | split grid | `rawhtml/foundationdesign.html` |
| 8 | CTA banner | `cta_block` (existing, `foundation-cta`) | banner | `rawhtml/foundationdesign.html` |

## Deploy parts

### 1. Theme changes (web/themes/custom/corporate_theme/)

- `css/foundation.css` — stylesheet for all five sections
- `js/foundation.js` — interactions (journey carousel, activities accordion,
  impact before/after slider)
- `corporate_theme.libraries.yml` — new `foundation` library
- `templates/paragraphs/paragraph--title-cards.html.twig`
  (foundation-journey / foundation-activities / foundation-gallery)
- `templates/paragraphs/paragraph--cards.html.twig` (foundation-impact branch)
- `templates/paragraphs/paragraph--cta-block.html.twig` (foundation-cta branch)
- `corporate_theme.theme` — attaches the `foundation` library automatically
  when a paragraph's `field_class` contains a foundation class

Templates only activate their custom layout when the matching `field_class`
value is present. All other uses of `title_cards`, `cards` and `cta_block`
render exactly as before (`{{ content }}`).

### 2. Custom module (web/modules/custom/cybcorp_foundation_tools/)

Provides **URL-triggered endpoints** so an admin can create/import the demo
content by opening a URL in the browser — **no drush required on the server**.

Routes (both require the `administer site configuration` permission, i.e. you
must be logged in as an admin):

| URL | What it does |
|-----|--------------|
| `/create-foundation-sections?nid=301` | Creates Foundation sections 4–8 and appends them to the node. |
| `/import-foundation-demo?nid=301&url=https://...` | Fetches the design HTML and maps its `<title>` / meta description onto the CTA (section 8). With no `url`, reads the local `rawhtml/foundationdesign.html`. |

Deployment steps (no drush needed):

1. Upload the module folder to `web/modules/custom/cybcorp_foundation_tools/`.
2. In the browser, go to **admin → Extend** (`/admin/modules`) and enable
   **Cybcorp Foundation Tools**.
3. Logged in as admin, open `/create-foundation-sections`.
4. Open `/import-foundation-demo` (with `?url=` to pull live demo text, or
   without to use the local reference file).

> Only run these once. Re-running appends duplicate sections. Remove any
> duplicates through the node's paragraph list if you click twice.
>
> Images/media fields are intentionally left empty (media requires file
> uploads). Assign images in the node edit UI (`/node/301/edit`).

### 3. config/ — imported configs

The **Our Impact** section needs two new paragraph bundles that must be imported:

- `paragraphs.paragraphs_type.impact` and `paragraphs.paragraphs_type.impact_item`
- Fields: `field_impact_items` (ERR, nested children), `field_before_image`,
  `field_after_image`, `field_description`, `field_title`, `field_impact_style`,
  `field_impact_width` (impact), `field_before_image`/`field_after_image`/`field_title`
  (impact_item), plus `add_stats` display additions (`field_stats_display`,
  `field_stats_layout`).
- Updated `field.field.node.page.field_add_paragraph.yml` (target_bundles now
  include `impact`).

**Critical — paragraph type permissions.** The site has the
`paragraphs_type_permissions` module enabled, which hides any paragraph whose
bundle permission is not granted. The new bundles have **no view permission by
default**, so the impact section is silently dropped from the page until the
roles are granted:

- `view paragraph content impact`
- `view paragraph content impact_item`

Grant these to the **anonymous** and **authenticated** roles. The two updated
role configs are included here (`user.role.anonymous.yml`,
`user.role.authenticated.yml`) and already contain those grants, so importing
them applies the fix. On a running site you can also grant them non-interactively:

```
drush role:perm:add anonymous "view paragraph content impact,view paragraph content impact_item"
drush role:perm:add authenticated "view paragraph content impact,view paragraph content impact_item"
drush cr
```

Without this step the page will load but "Our Impact" will not render (no error,
just silently missing) — this is the symptom we debugged and fixed.

## Hard reload / cache clear after deploy

Clear the cache through the admin UI (**admin → Configuration → Development →
Performance → Clear all caches**) or with `drush cr` where available.
