/**
 * @file
 * AI Hub behaviours.
 *
 * Auto-submit of the "AI in Practice" filters (including AJAX updates) is
 * handled by Better Exposed Filters (autosubmit + hidden Apply button).
 * This behaviour only guarantees the search placeholder text.
 */
(function ($, Drupal) {
  'use strict';

  Drupal.behaviors.aiHubPracticeFilters = {
    attach: function attach(context) {
      var $keys = $('input[name="keys"]', context).once('ai-hub-placeholder');
      if ($keys.length && !$keys.attr('placeholder')) {
        $keys.attr('placeholder', 'Skills or Keyword');
      }
    }
  };
})(jQuery, Drupal);
