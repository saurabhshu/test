// =======================================================
// Our Presence Section
// Handles country navigation, continent tabs, map markers,
// and address list synchronization.
// Custom region dropdown is optional.
// =======================================================
jQuery(document).ready(function () {

  /**
   * Initialize all interactions for the Our Presence section.
   */
  function initGlobalOffice() {

    /* ======================================================
     * Cache Frequently Used DOM Elements
     * ====================================================== */

    // Region dropdown is OPTIONAL now.
    const selectSelected =
      document.querySelector('.select-selected');

    const selectItems =
      document.querySelector('.select-items');

    const countryLinks =
      document.querySelectorAll('.select-items a');

    const markers =
      document.querySelectorAll('.marker');

    const continentTabs =
      document.querySelectorAll(
        '#quicktabs-global-office-cyb a'
      );

    const sections =
      document.querySelectorAll(
        '.our-presence-addresses .views-row'
      );

    const addressContainer =
      document.querySelector(
        '.our-presence-addresses'
      );


    // ======================================================
    // CHANGED:
    // Only addressContainer is required.
    // The region dropdown is no longer required.
    // ======================================================

    if (!addressContainer) {
      return;
    }


    /**
     * Prevent scroll events from updating the active state
     * while a programmatic smooth scroll is in progress.
     */
    let scrollLock = false;


    /* ======================================================
     * Country → Continent Mapping
     * ====================================================== */

    const continentMap = {
      india: 'india',
      brazil: 'latam',

      japan: 'asia_pacific',
      singapore: 'asia_pacific',

      australia: 'australia',

      usa: 'americas',
      canada: 'americas',

      uk: 'emea',
      germany: 'emea',
      france: 'emea',
      ireland: 'emea',
      netherlands: 'emea',
      sweden: 'emea',
      poland: 'emea'
    };


    /**
     * Returns continent key for a given country.
     *
     * @param {string} country
     * @returns {string}
     */
    function getContinent(country) {

      return continentMap[country] || '';

    }


    /* ======================================================
     * Scroll Active Continent Tab Into View
     * ====================================================== */

    function scrollActiveTabIntoView() {

      const ul =
        document.querySelector(
          '#quicktabs-global-office-cyb'
        );

      if (!ul) {
        return;
      }

      const activeLi =
        ul.querySelector('li.active');

      if (!activeLi) {
        return;
      }

      const ulRect =
        ul.getBoundingClientRect();

      const liRect =
        activeLi.getBoundingClientRect();

      const targetLeft =
        ul.scrollLeft +
        (liRect.left - ulRect.left) -
        (
          ulRect.width / 2 -
          liRect.width / 2
        );

      ul.scrollTo({
        left: Math.max(0, targetLeft),
        behavior: 'smooth'
      });

    }


    /* ======================================================
     * Update Active Marker and Tab
     * ====================================================== */

    function updateMarkersAndTabs(country) {

      country =
        country.toLowerCase();

      const continent =
        getContinent(country);


      /* ------------------------------------------------------
       * Highlight Selected Map Marker
       * ------------------------------------------------------ */

      markers.forEach(marker => {

        const markerCountry =
          marker.dataset.country
            ?.toLowerCase();

        marker.classList.toggle(
          'active',
          markerCountry === country
        );

      });


      /* ------------------------------------------------------
       * Highlight Corresponding Continent Tab
       * ------------------------------------------------------ */

      continentTabs.forEach(tab => {

        const tabContinent =
          tab.dataset.continent
            ?.toLowerCase();

        const parent =
          tab.parentElement;

        if (parent) {

          parent.classList.toggle(
            'active',
            tabContinent === continent
          );

        }

      });


      // ======================================================
      // CHANGED:
      // Update dropdown only if dropdown still exists.
      // ======================================================

      if (
        selectSelected &&
        countryLinks.length
      ) {

        const link =
          [...countryLinks].find(
            a =>
              a.dataset.country
                ?.toLowerCase() === country
          );

        if (link) {

          const span =
            selectSelected.querySelector('span');

          if (span) {

            span.textContent =
              link.textContent.trim();

          }

        }

      }


      scrollActiveTabIntoView();

    }


    /* ======================================================
     * Activate Selected Country
     * ====================================================== */

    function activateCountry(country) {

      country =
        country.toLowerCase();

      scrollLock = true;

      const section =
        document.getElementById(country);


      if (section) {

        const heading =
          section.previousElementSibling
            ?.classList.contains(
              'country-heading'
            )
            ? section.previousElementSibling
            : section;


        const target =
          heading.getBoundingClientRect().top -
          addressContainer.getBoundingClientRect().top +
          addressContainer.scrollTop -
          20;


        addressContainer.scrollTo({
          top: target,
          behavior: 'smooth'
        });


        const waitScroll =
          setInterval(() => {

            const distance =
              Math.abs(
                addressContainer.scrollTop -
                target
              );


            const atBottom =
              addressContainer.scrollTop +
                addressContainer.clientHeight >=
              addressContainer.scrollHeight - 1;


            const atTop =
              addressContainer.scrollTop <= 0;


            if (
              distance < 5 ||
              atBottom ||
              atTop
            ) {

              clearInterval(waitScroll);

              scrollLock = false;

              updateMarkersAndTabs(
                country
              );

            }

          }, 50);

      } else {

        scrollLock = false;

        updateMarkersAndTabs(
          country
        );

      }

    }


    /* ======================================================
     * Address Container Scroll Handler
     * ====================================================== */

    function handleScroll() {

      if (scrollLock) {
        return;
      }


      let currentCountry = null;


      const containerRect =
        addressContainer.getBoundingClientRect();


      /* ------------------------------------------------------
       * Detect Current Country
       * ------------------------------------------------------ */

      sections.forEach(section => {

        const rect =
          section.getBoundingClientRect();


        if (
          rect.top <
            containerRect.top +
              containerRect.height * 0.35 &&
          rect.bottom >
            containerRect.top +
              containerRect.height * 0.25
        ) {

          currentCountry =
            section.id.toLowerCase();

        }

      });


      /* ------------------------------------------------------
       * Ensure Last Country Becomes Active At Bottom
       * ------------------------------------------------------ */

      if (
        addressContainer.scrollTop +
          addressContainer.clientHeight >=
        addressContainer.scrollHeight - 2
      ) {

        const last =
          sections[sections.length - 1];

        if (last) {

          currentCountry =
            last.id.toLowerCase();

        }

      }


      if (!currentCountry) {
        return;
      }


      updateMarkersAndTabs(
        currentCountry
      );

    }


    /* ======================================================
     * Address Container Scroll Listener
     * ====================================================== */

    addressContainer.addEventListener(
      'scroll',
      handleScroll,
      {
        passive: true
      }
    );


    /* ======================================================
     * Custom Country Dropdown
     *
     * CHANGED:
     * Only initialize if the dropdown exists.
     * ====================================================== */

    if (
      selectSelected &&
      selectItems
    ) {

      /**
       * Toggle dropdown visibility.
       */
      selectSelected.addEventListener(
        'click',
        e => {

          e.stopPropagation();

          selectItems.classList.toggle(
            'd-flex'
          );

        }
      );


      /**
       * Navigate to selected country.
       */
      countryLinks.forEach(link => {

        link.addEventListener(
          'click',
          e => {

            e.preventDefault();

            const country =
              link.dataset.country
                ?.toLowerCase();

            if (!country) {
              return;
            }

            activateCountry(
              country
            );

            selectItems.classList.remove(
              'd-flex'
            );

          }
        );

      });


      /**
       * Close dropdown when clicking outside.
       */
      document.addEventListener(
        'click',
        e => {

          if (
            !e.target.closest(
              '.custom-select'
            )
          ) {

            selectItems.classList.remove(
              'd-flex'
            );

          }

        }
      );

    }


    /* ======================================================
     * Continent Tab Navigation
     * ====================================================== */

    continentTabs.forEach(tab => {

      tab.addEventListener(
        'click',
        e => {

          e.preventDefault();

          const continent =
            tab.dataset.continent;

          if (!continent) {
            return;
          }


          const firstCountry =
            [...sections].find(
              sec =>
                getContinent(
                  sec.id.toLowerCase()
                ) === continent
            );


          if (firstCountry) {

            activateCountry(
              firstCountry.id
            );

          }

        }
      );

    });


    /* ======================================================
     * Map Marker Navigation
     * ====================================================== */

    markers.forEach(marker => {

      marker.addEventListener(
        'click',
        e => {

          e.preventDefault();

          const country =
            marker.dataset.country
              ?.toLowerCase();

          if (!country) {
            return;
          }

          activateCountry(
            country
          );

        }
      );

    });

  }


  /* =======================================================
   * Reinitialize After QuickTabs AJAX Content Is Loaded
   * ======================================================= */

  const targetNode =
    document.querySelector(
      '#quicktabs-container-global-office-cyb'
    );


  if (targetNode) {

    const observer =
      new MutationObserver(() => {

        setTimeout(() => {

          initGlobalOffice();

        }, 100);

      });


    observer.observe(
      targetNode,
      {
        childList: true,
        subtree: true
      }
    );

  }


  /* =======================================================
   * Initial Page Load
   * ======================================================= */

  initGlobalOffice();

});