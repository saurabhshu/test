/**
 * @file
 * Cybage Foundation section interactions.
 * Triggered via .foundation-* classes on reused paragraph components.
 */
(function (Drupal, once) {
  'use strict';

  Drupal.behaviors.foundationSections = {
    attach: function (context) {
      // 4. Our Journey — timeline carousel
      once('fd-journey', '.foundation-journey .fd-journey__track', context).forEach(function (track) {
        var cards = Array.prototype.slice.call(track.querySelectorAll('.fd-journey__card'));
        if (cards.length === 0) {
          return;
        }
        var root = track.closest('.foundation-journey');
        var nodes = Array.prototype.slice.call(root.querySelectorAll('.fd-node'));
        var dots = Array.prototype.slice.call(root.querySelectorAll('.fd-journey__dot'));
        var prevBtn = root.querySelector('.fd-journey__prev');
        var nextBtn = root.querySelector('.fd-journey__next');
        var itemsPerPage = 3;
        var currentPage = 0;
        var totalPages = Math.max(1, Math.ceil(cards.length / itemsPerPage));

        function getStepWidth() {
          var cardWidth = cards[0].getBoundingClientRect().width;
          var gap = 30;
          return (cardWidth + gap) * itemsPerPage;
        }

        function updateView(pageIndex) {
          currentPage = pageIndex;
          nodes.forEach(function (node) {
            var page = parseInt(node.getAttribute('data-page'), 10);
            node.classList.toggle('active', page === currentPage);
          });
          dots.forEach(function (dot, idx) {
            dot.classList.toggle('active', idx === currentPage);
          });
          if (prevBtn) { prevBtn.disabled = currentPage === 0; }
          if (nextBtn) { nextBtn.disabled = currentPage === totalPages - 1; }
        }

        function goToPage(pageIndex) {
          if (pageIndex < 0 || pageIndex >= totalPages) { return; }
          track.scrollTo({ left: pageIndex * getStepWidth(), behavior: 'smooth' });
          updateView(pageIndex);
        }

        if (nextBtn) { nextBtn.addEventListener('click', function () { goToPage(currentPage + 1); }); }
        if (prevBtn) { prevBtn.addEventListener('click', function () { goToPage(currentPage - 1); }); }

        nodes.forEach(function (node) {
          node.addEventListener('click', function () {
            goToPage(parseInt(node.getAttribute('data-page'), 10));
          });
        });
        dots.forEach(function (dot) {
          dot.addEventListener('click', function () {
            goToPage(parseInt(dot.getAttribute('data-page'), 10));
          });
        });

        var scrollTimeout;
        track.addEventListener('scroll', function () {
          clearTimeout(scrollTimeout);
          scrollTimeout = setTimeout(function () {
            var stepWidth = getStepWidth();
            var page = Math.round(track.scrollLeft / stepWidth);
            if (page !== currentPage && page < totalPages) {
              updateView(page);
            }
          }, 50);
        });

        updateView(0);
      });

      // 5. Our Activities — expanding cards
      once('fd-activities', '.foundation-activities .fd-activity__card', context).forEach(function (card) {
        card.addEventListener('click', function () {
          var container = card.closest('.fd-activities');
          if (!container) { return; }
          Array.prototype.forEach.call(container.querySelectorAll('.fd-activity__card'), function (c) {
            c.classList.remove('active');
          });
          card.classList.add('active');
        });
      });

      // 6. Our Impact — before/after comparison slider
      once('fd-impact', '.foundation-impact .fd-impact__card', context).forEach(function (card) {
        var beforeImage = card.querySelector('.fd-impact__before');
        var divider = card.querySelector('.fd-impact__divider');
        if (!beforeImage || !divider) { return; }

        var isDragging = false;

        function updateSlider(x) {
          var rect = card.getBoundingClientRect();
          var position = Math.max(0, Math.min(x - rect.left, rect.width));
          var percent = (position / rect.width) * 100;
          beforeImage.style.width = percent + '%';
          divider.style.left = percent + '%';
        }

        divider.addEventListener('mousedown', function (e) {
          isDragging = true;
          card.classList.add('dragging');
          e.preventDefault();
        });
        window.addEventListener('mousemove', function (e) {
          if (!isDragging) { return; }
          updateSlider(e.clientX);
        });
        window.addEventListener('mouseup', function () {
          if (!isDragging) { return; }
          isDragging = false;
          card.classList.remove('dragging');
        });
        divider.addEventListener('touchstart', function () {
          isDragging = true;
          card.classList.add('dragging');
        });
        window.addEventListener('touchmove', function (e) {
          if (!isDragging) { return; }
          updateSlider(e.touches[0].clientX);
        });
        window.addEventListener('touchend', function () {
          isDragging = false;
          card.classList.remove('dragging');
        });
      });

      // 7. Impact (dedicated bundle) — before/after comparison slider (.fd-cc)
      once('fd-cc', '.fd-cc', context).forEach(function (slider) {
        var beforeImg = slider.querySelector('.fd-cc__img--after');
        var divider = slider.querySelector('.fd-cc__divider');
        if (!beforeImg || !divider) { return; }

        var isDragging = false;

        function updateSlider(x) {
          var rect = slider.getBoundingClientRect();
          var position = Math.max(0, Math.min(x - rect.left, rect.width));
          var percent = (position / rect.width) * 100;
          beforeImg.style.clipPath = 'inset(0 0 0 ' + percent + '%)';
          divider.style.left = percent + '%';
          slider.setAttribute('aria-valuenow', Math.round(percent));
        }

        divider.addEventListener('mousedown', function (e) {
          isDragging = true;
          slider.classList.add('dragging');
          e.preventDefault();
        });
        window.addEventListener('mousemove', function (e) {
          if (!isDragging) { return; }
          updateSlider(e.clientX);
        });
        window.addEventListener('mouseup', function () {
          if (!isDragging) { return; }
          isDragging = false;
          slider.classList.remove('dragging');
        });
        divider.addEventListener('touchstart', function () {
          isDragging = true;
          slider.classList.add('dragging');
        });
        window.addEventListener('touchmove', function (e) {
          if (!isDragging) { return; }
          updateSlider(e.touches[0].clientX);
        });
        window.addEventListener('touchend', function () {
          isDragging = false;
          slider.classList.remove('dragging');
        });
      });
    }
  };
})(Drupal, once);
