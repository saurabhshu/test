
document.addEventListener('DOMContentLoaded', function () {
    const lenis = new Lenis({
      autoRaf: true,

       prevent: (node) => {
    return node.closest('.Industries-section, .our-presence-section');
  }
    });


  });

const excludeSelectors = '.cta-homepage, .platform, .why-join-cyb-banner';


document.querySelectorAll(`.description_link .field--name-field-link a, .featured-section-main-wrapper  .dynamic-right-slider-wrapper  a,   .field--name-field-link a,  .customer-success .cta a,.announcement-section .split-section-wrapper .carousel-column-slider .views-field-view-node a`)

  .forEach(link => {
     if (link.closest(excludeSelectors)) return;
    const icon = document.createElement('i');
    icon.className = 'ri-arrow-right-line';
    link.appendChild(icon);
  });

document.querySelectorAll(`.why-join-cyb-banner .field--name-field-link a`)
  .forEach(link => {
    const div = document.createElement('div');
    div.className = 'career-link-arrow';
    div.textContent = '↗';
    link.appendChild(div);
  });


document.querySelectorAll('.node--type-sustainability .paragraph--view-mode--our-env .stat-data .stat .percentage')
  .forEach(link => {
    if (link.closest(excludeSelectors)) return;

    const icon = document.createElement('i');
    icon.className = 'ri-arrow-down-line';

    // Insert icon before the text
    link.prepend(icon);
  });

  document.querySelectorAll(`.featured-section-main-wrapper .static-left-hero-card  a,.node--type-sustainability .reports__wrapper .reports__pdf-list .field--name-field-pdf-with-details .field__item a `)
  .forEach(link => {
  if (link.closest(excludeSelectors)) return;

  const icon = document.createElement('i');
  icon.className = 'ri-arrow-right-long-line';
  link.appendChild(icon);
});

  // document.querySelectorAll('.platform .field--name-field-eyebrow-title')
  // .forEach(link => {
  //   const icon = document.createElement('i');
  //   icon.className = 'ri-circle-fill';
  //   link.prepend(icon);
  //   icon.insertAdjacentText('afterend', ' ');
  // });
//adding span in ceo desk section link
document.querySelectorAll('.ceo-desk .field--name-field-link a ').forEach(link => {
  const text = [...link.childNodes].find(node => node.nodeType === Node.TEXT_NODE);

  if (text && text.textContent.trim()) {
    const span = document.createElement('span');
    span.textContent = text.textContent;
    link.replaceChild(span, text);
  }
});
(function (Drupal, once) {
  Drupal.behaviors.industriesImageWrapperClass = {
    attach: function (context) {
      once('industries-image-wrapper-class', '.industries-image-wrapper', context).forEach(function (wrapper) {
        wrapper.parentElement.classList.add('img-main-wrap');
      });
    }
  };
})(Drupal, once);

const observer = new MutationObserver(() => {
  const activeTab = document.querySelector('#quicktabs-industries-section .quicktabs-tabs .list-group-item.active');

  if (activeTab) {
    // Keep the active tab visible within the horizontally scrolling tab strip.
    activeTab.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });
  }
});

const quicktabsTabs = document.querySelector('.quicktabs-tabs');

if (quicktabsTabs) {
  observer.observe(quicktabsTabs, {
    subtree: true,
    attributes: true,
    attributeFilter: ['class']
  });
}

// Scroll-jacked stepping through the Industries tabs: while the section is
// engaged, each wheel tick advances/retreats one tab instead of scrolling the
// page. Once you step past the first/last tab, the scroll releases and the
// page continues normally (up to whatever precedes it, or down into
// #next-section).
(function (Drupal, once) {

  Drupal.behaviors.industriesScrollJack = {
    attach: function (context) {

      once('industries-scroll-jack', '#quicktabs-industries-section', context).forEach(function (section) {

        const tabs = [...section.querySelectorAll('.quicktabs-tabs .list-group-item')];

        if (tabs.length < 2) {
          return;
        }

        const STEP_THRESHOLD = 40;       // px of accumulated wheel delta per tab step
        const TRANSITION_LOCK_MS = 500;  // matches the underline/tab transition duration
        const BELOW_VIEWPORT_GRACE = 3;  // free native scroll-up ticks before re-engaging

        let activeIndex = Math.max(0, tabs.findIndex(tab => tab.classList.contains('active')));
        let wheelAccum = 0;
        let transitioning = false;
        let belowViewport = false;
        let graceCount = 0;
        let touchStartY = 0;

        function goToTab(index) {
          activeIndex = index;
          transitioning = true;
          tabs[activeIndex].querySelector('a')?.click();
          setTimeout(() => { transitioning = false; }, TRANSITION_LOCK_MS);
        }

        function isEngaged() {
          const rect = section.getBoundingClientRect();
          const vh = window.innerHeight;
          // Engaged once the section's top has scrolled into the upper part
          // of the viewport and its bottom hasn't scrolled past the top yet.
          return rect.bottom >= vh * 0.15 && rect.top <= vh * 0.28;
        }

        function trackBelowViewport() {
          belowViewport = section.getBoundingClientRect().top >= window.innerHeight;
        }

        trackBelowViewport();
        window.addEventListener('scroll', trackBelowViewport, { passive: true });

        function onWheel(e) {

          // Scrolling up while the section is still fully below the
          // viewport: let a few native scroll ticks bring it closer first,
          // instead of snapping straight into the jack.
          if (e.deltaY < 0 && belowViewport) {
            const rect = section.getBoundingClientRect();
            const vh = window.innerHeight;

            if (rect.bottom > vh * 0.65 && graceCount < BELOW_VIEWPORT_GRACE) {
              graceCount += 1;
              belowViewport = rect.top >= vh;
              return;
            }

            belowViewport = false;
          } else {
            graceCount = 0;
          }

          if (!isEngaged()) {
            return;
          }

          const scrollingDown = e.deltaY > 0;

          if (scrollingDown) {
            if (activeIndex < tabs.length - 1) {
              wheelAccum += e.deltaY;

              if (wheelAccum >= STEP_THRESHOLD && !transitioning) {
                wheelAccum = 0;
                goToTab(activeIndex + 1);
              }

              e.preventDefault();
            } else {
              wheelAccum = 0; // at last tab: release, let the page scroll on
            }
          } else if (activeIndex > 0) {
            wheelAccum += e.deltaY;

            if (wheelAccum <= -STEP_THRESHOLD && !transitioning) {
              wheelAccum = 0;
              goToTab(activeIndex - 1);
            }

            e.preventDefault();
          } else {
            wheelAccum = 0; // at first tab: release, let the page scroll up
          }
        }

        window.addEventListener('wheel', onWheel, { passive: false });

        // Touch swipe: mirrors the wheel logic but never preventDefault()s,
        // since blocking native scroll on touchmove is unreliable on mobile -
        // the tab just changes alongside whatever scrolling already happens.
        function onTouchStart(e) {
          touchStartY = isEngaged() ? e.touches[0].clientY : 0;
        }

        function onTouchEnd(e) {
          if (!touchStartY || transitioning) {
            return;
          }

          const deltaY = touchStartY - e.changedTouches[0].clientY;
          touchStartY = 0;

          if (!isEngaged()) {
            return;
          }

          if (deltaY > 50 && activeIndex < tabs.length - 1) {
            goToTab(activeIndex + 1);
          } else if (deltaY < -50 && activeIndex > 0) {
            goToTab(activeIndex - 1);
          }
        }

        window.addEventListener('touchstart', onTouchStart, { passive: true });
        window.addEventListener('touchend', onTouchEnd, { passive: true });

      });

    }
  };

})(Drupal, once);
//active class for industry section
// (function ($, Drupal, once) {

//   Drupal.behaviors.industryNav = {
//     attach: function (context) {

//       // Set first nav item active
//       once("industry-nav-init", ".industry-nav-list .nav-item", context)
//         .forEach(function (element, index) {
//           if (index === 0) {
//             $(element).addClass("active");
//           }
//         });

//       // Handle click
//       once("industry-nav-click", ".industry-nav-list .nav-item", context)
//         .forEach(function (element) {

//           $(element).on("click", function (e) {

//             e.preventDefault();

//             console.log("Clicked:", $(this).attr("id"));

//             // Remove active from nav items
//             $(".industry-nav-list .nav-item").removeClass("active");

//             // Add active to clicked nav item
//             $(this).addClass("active");

//             // Get card ID from href
//             var cardId = $(this).find(".nav-anchor-link").attr("href");

//             console.log("Target card:", cardId);

//             // Remove active from all cards
//             $(".industry-card").removeClass("active");

//             // Add active to matching card
//             $(cardId).addClass("active");

//           });

//         });

//     }
//   };

// })(jQuery, Drupal, once);
  jQuery(".industry-nav-list .nav-item").first().addClass("active");
(function ($, Drupal, once) {

  Drupal.behaviors.industryNav = {
    attach: function (context) {

          // Handle click
      once("industry-nav-click", ".industry-nav-list .nav-item", context)
        .forEach(function (element) {

          $(element).on("click", function (e) {

            e.preventDefault();

            $(".industry-nav-list .nav-item").removeClass("active");
            $(this).addClass("active");

            var cardId = $(this).find(".nav-anchor-link").attr("href");

            $(".industry-card").removeClass("active");
            $(cardId).addClass("active");

          });

        });

    }
  };

})(jQuery, Drupal, once);

//navigation

// (function (Drupal, once) {
//   Drupal.behaviors.secondaryNavigationSticky = {
//     attach(context) {
//       once('secondary-navigation-sticky', '.secondary-navigation', context).forEach((wrapper) => {

//         const header = document.querySelector('header');
//         const container = wrapper.closest('.container-custom');
//         const wrapperTop = wrapper.getBoundingClientRect().top + window.scrollY;

//         function getHeaderHeight() {
//           return window.innerWidth <= 767
//             ? (header ? header.offsetHeight : 67) // mobile
//             : 0; // desktop (or use header.offsetHeight if needed)
//         }

//         function stickyNavigation() {
//           const headerHeight = getHeaderHeight();

//           if (window.scrollY >= wrapperTop) {
//             const rect = container.getBoundingClientRect();

//             wrapper.classList.add('is-fixed');
//             wrapper.style.top = `${headerHeight}px`;
//             wrapper.style.left = `${rect.left}px`;
//             wrapper.style.width = `${rect.width}px`;
//           } else {
//             wrapper.classList.remove('is-fixed');
//             wrapper.style.top = '';
//             wrapper.style.left = '';
//             wrapper.style.width = '';
//           }
//         }

//         window.addEventListener('scroll', stickyNavigation);
//         window.addEventListener('resize', stickyNavigation);

//         stickyNavigation();
//       });
//     }
//   };
// })(Drupal, once);

// (function (Drupal, once) {
//   Drupal.behaviors.secondaryNavigationSticky = {
//     attach(context) {
//       once('secondary-navigation-sticky', '.secondary-navigation', context).forEach((wrapper) => {

//         const HEADER_HEIGHT = 67;

//         let wrapperTop;
//         let wrapperLeft;
//         let wrapperWidth;

//         function updateMeasurements() {
//           // Temporarily remove fixed state
//           const wasFixed = wrapper.classList.contains('is-fixed');

//           if (wasFixed) {
//             wrapper.classList.remove('is-fixed');
//             wrapper.style.top = '';
//             wrapper.style.left = '';
//             wrapper.style.width = '';
//           }

//           const rect = wrapper.getBoundingClientRect();

//           wrapperTop = rect.top + window.pageYOffset;
//           wrapperLeft = rect.left;
//           wrapperWidth = rect.width;

//           if (wasFixed) {
//             wrapper.classList.add('is-fixed');
//           }
//         }

//         function stickyNavigation() {
//           if (window.pageYOffset >= wrapperTop - HEADER_HEIGHT) {

//             wrapper.classList.add('is-fixed');
//             wrapper.style.top = `${HEADER_HEIGHT}px`;
//             wrapper.style.left = `${wrapperLeft}px`;
//             wrapper.style.width = `${wrapperWidth}px`;

//           } else {

//             wrapper.classList.remove('is-fixed');
//             wrapper.style.top = '';
//             wrapper.style.left = '';
//             wrapper.style.width = '';

//           }
//         }

//         updateMeasurements();
//         stickyNavigation();

//         window.addEventListener('scroll', stickyNavigation);

//         window.addEventListener('resize', () => {
//           updateMeasurements();
//           stickyNavigation();
//         });

//         window.addEventListener('load', () => {
//           updateMeasurements();
//           stickyNavigation();
//         });

//       });
//     }
//   };
// })(Drupal, once);


(function (Drupal, once) {
  Drupal.behaviors.secondaryNavigationSticky = {
    attach(context) {
      once(
        'secondary-navigation-sticky',
        '.secondary-navigation',
        context
      ).forEach((wrapper) => {
        // Find the main header.
        const header =
          document.querySelector('header') ||
          document.querySelector('.site-header') ||
          document.querySelector('.header');

        if (!header) {
          console.error(
            'Secondary navigation: header not found.'
          );
          return;
        }

        // Create a placeholder to preserve the navigation's
        // original space when it becomes fixed.
        const placeholder = document.createElement('div');

        placeholder.className =
          'secondary-navigation-placeholder';

        placeholder.style.display = 'none';

        wrapper.parentNode.insertBefore(
          placeholder,
          wrapper
        );

        let wrapperTop = 0;
        let wrapperLeft = 0;
        let wrapperWidth = 0;
        let wrapperHeight = 0;

        /**
         * Get the current header height.
         */
        function getHeaderHeight() {
          return header.getBoundingClientRect().height;
        }

        /**
         * Measure the secondary navigation while it is
         * in its normal document position.
         */
        function updateMeasurements() {
          wrapper.classList.remove('is-fixed');

          wrapper.style.position = '';
          wrapper.style.top = '';
          wrapper.style.left = '';
          wrapper.style.width = '';

          const rect = wrapper.getBoundingClientRect();

          wrapperTop = rect.top + window.scrollY;
          wrapperLeft = rect.left;
          wrapperWidth = rect.width;
          wrapperHeight = rect.height;

          // Preserve the original space.
          placeholder.style.height =
            `${wrapperHeight}px`;
        }

        /**
         * Handle sticky/fixed navigation.
         */
        function stickyNavigation() {
          const headerHeight = getHeaderHeight();

          const shouldFix =
            window.scrollY >=
            wrapperTop - headerHeight;

          if (shouldFix) {
            // Keep the original space in the document.
            placeholder.style.display = 'block';

            wrapper.classList.add('is-fixed');

            wrapper.style.position = 'fixed';

            // Position directly underneath the actual header.
            wrapper.style.top =
              `${headerHeight}px`;

            wrapper.style.left =
              `${wrapperLeft}px`;

            wrapper.style.width =
              `${wrapperWidth}px`;

            wrapper.style.zIndex = '998';
          } else {
            placeholder.style.display = 'none';

            wrapper.classList.remove('is-fixed');

            wrapper.style.position = '';
            wrapper.style.top = '';
            wrapper.style.left = '';
            wrapper.style.width = '';
            wrapper.style.zIndex = '';
          }
        }

        /**
         * Recalculate everything.
         */
        function refresh() {
          updateMeasurements();
          stickyNavigation();
        }

        // Initial setup.
        refresh();

        // Scroll.
        window.addEventListener(
          'scroll',
          stickyNavigation,
          { passive: true }
        );

        // Resize.
        window.addEventListener(
          'resize',
          refresh
        );

        // Images/fonts/etc. may change header dimensions.
        window.addEventListener(
          'load',
          refresh
        );
      });
    }
  };
})(Drupal, once);

//code for active of nav tabs for sustainability page
(function ($, Drupal, once) {

  Drupal.behaviors.sustainabilityNav = {
    attach: function (context) {

      var $tabs = $(".secondary-navigation .navigation-tabs li a", context);

      // First tab active by default
      $tabs.first().addClass("active");

      once("sustainability-nav-click", ".secondary-navigation .navigation-tabs li a", context)
        .forEach(function (element) {

          $(element).on("click", function (e) {
            e.preventDefault();

            $tabs.removeClass("active");
            $(this).addClass("active");

          });

        });

    }
  };

})(jQuery, Drupal, once);



// (function (Drupal, once) {

//   Drupal.behaviors.sustainabilityNavigation = {
//     attach: function (context) {

//       once('sustainability-navigation', '.navigation-tabs', context).forEach(function (nav) {

//         const links = nav.querySelectorAll('li a');

//         const sections = [...links]
//           .map(link => document.querySelector(link.getAttribute('href')))
//           .filter(Boolean);

//         /**
//          * Update active navigation while scrolling
//          */
//         function updateActiveNav() {

//           const scrollPosition = window.scrollY + 220;
//           let currentSection = null;

//           sections.forEach(section => {
//             if (scrollPosition >= section.offsetTop) {
//               currentSection = section;
//             }
//           });

//           links.forEach(link => link.classList.remove('active'));

//           if (currentSection) {

//             const activeLink = nav.querySelector(
//               `a[href="#${currentSection.id}"]`
//             );

//             if (activeLink) {

//               activeLink.classList.add('active');

//               // Keep active tab visible on mobile
//               activeLink.scrollIntoView({
//                 behavior: 'smooth',
//                 inline: 'center',
//                 block: 'nearest'
//               });

//             }

//           } else if (links.length) {

//             // Default first tab active
//             links[0].classList.add('active');

//           }

//         }

//         /**
//          * Smooth jump links
//          */
//         links.forEach(link => {

//           link.addEventListener('click', function (e) {

//             e.preventDefault();

//             const target = document.querySelector(this.getAttribute('href'));

//             if (!target) {
//               return;
//             }

//             const offset = 200;

//             const targetPosition =
//               target.getBoundingClientRect().top +
//               window.pageYOffset -
//               offset;

//             window.scrollTo({
//               top: targetPosition,
//               behavior: 'smooth'
//             });

//           });

//         });

//         window.addEventListener('scroll', updateActiveNav, { passive: true });

//         updateActiveNav();

//       });

//     }
//   };

// })(Drupal, once);

(function (Drupal, once) {

  Drupal.behaviors.sustainabilityNavigation = {
    attach: function (context) {

      once('sustainability-navigation', '.navigation-tabs', context)
        .forEach(function (nav) {

          const links = [...nav.querySelectorAll('li a')];
          const OFFSET = 200;

          const sections = links
            .map(link => {
              const href = link.getAttribute('href');
              return href ? document.querySelector(href) : null;
            })
            .filter(Boolean);

          /**
           * Update active navigation while scrolling
           */
          function updateActiveNav() {

            const scrollPosition = window.scrollY + OFFSET + 10;
            let currentSection = null;

            sections.forEach(section => {

              const sectionTop =
                section.getBoundingClientRect().top +
                window.scrollY;

              if (scrollPosition >= sectionTop) {
                currentSection = section;
              }

            });

            links.forEach(link => {
              link.classList.remove('active');
            });

            if (currentSection) {

              const activeLink = nav.querySelector(
                `a[href="#${currentSection.id}"]`
              );

              if (activeLink) {

                activeLink.classList.add('active');

                // Keep active tab visible on mobile
                if (window.innerWidth <= 767) {
                  activeLink.scrollIntoView({
                    behavior: 'smooth',
                    inline: 'center',
                    block: 'nearest'
                  });
                }

              }

            } else if (links.length) {

              links[0].classList.add('active');

            }

          }

          /**
           * Smooth jump links
           */
          links.forEach(link => {

            link.addEventListener('click', function (e) {

              e.preventDefault();

              const target = document.querySelector(
                this.getAttribute('href')
              );

              if (!target) {
                return;
              }

              /*
               * Default sections = 200px
               * Leadership section = 100px
               */
              const offset =
                target.id === 'a-message-from-our-leadership'
                  ? 100
                  : 200;

              const targetPosition =
                target.getBoundingClientRect().top +
                window.pageYOffset -
                offset;

              window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
              });

            });

          });

          window.addEventListener(
            'scroll',
            updateActiveNav,
            { passive: true }
          );

          updateActiveNav();

        });

    }
  };

})(Drupal, once);



//anouncement section for ipad
(function ($, Drupal, once) {
  Drupal.behaviors.announcementIpadFix = {
    attach: function (context) {

      once('announcement-ipad-fix', '.announcement-section .slick__slider', context).forEach(function (element) {

        var $slider = $(element);

        function refreshSlider() {
          // Run only on iPad width
          if (window.innerWidth >= 768 && window.innerWidth <= 1024) {
            if ($slider.hasClass('slick-initialized')) {
              $slider.slick('setPosition');
            }
          }
        }

        refreshSlider();

        $(window).on('resize orientationchange', refreshSlider);

        setTimeout(refreshSlider, 300);
        setTimeout(refreshSlider, 800);
      });

    }
  };
})(jQuery, Drupal, once);

(function (Drupal) {
  Drupal.behaviors.industryCardToggle = {
    attach: function (context) {

      const links = context.querySelectorAll(".nav-anchor-link");
      const cards = context.querySelectorAll(".industry-view-mode-card");

      if (!links.length || !cards.length) {
        return;
      }

      // Prevent attaching multiple times
      if (context.querySelector(".industry-view-mode-card").dataset.initialized) {
        return;
      }

      cards[0].dataset.initialized = "true";

      // Show only first card by default
      cards.forEach((card, index) => {
        card.style.display = index === 0 ? "block" : "none";
      });

      // First nav item active
      const navItems = context.querySelectorAll(".nav-item");

      navItems.forEach((item, index) => {
        item.classList.toggle("active", index === 0);
      });

      // Click event
      links.forEach(link => {

        link.addEventListener("click", function (e) {
          e.preventDefault();

          // Hide all cards
          cards.forEach(card => {
            card.style.display = "none";
          });

          // Remove active class
          navItems.forEach(item => {
            item.classList.remove("active");
          });

          // Convert href ID:
          // #card-media-advertising
          // becomes:
          // card-body-media-advertising
          const targetId = this.getAttribute("href")
            .replace("#card-", "card-body-");

          const targetCard = document.getElementById(targetId);

          if (targetCard) {
            targetCard.style.display = "block";
          }

          // Active menu item
          this.closest(".nav-item").classList.add("active");
        });

      });

    }
  };

})(Drupal);

//fro showing two slides on announcements


// const revealEls=document.querySelectorAll('.reveal');

// revealEls.forEach((el, index) => {
//   el.classList.add(`d${(index % 4) + 1}`); // d1, d2, d3, d4, then repeats
// });

// const io=new IntersectionObserver(entries=>{

// entries.forEach(entry=>{

// if(entry.isIntersecting){

// entry.target.classList.add('is-visible');
// io.unobserve(entry.target);

// }

// });

// },{threshold:.12});

// revealEls.forEach(el=>io.observe(el));


const revealEls = document.querySelectorAll('.reveal');

revealEls.forEach((el, index) => {
    console.log('entered');
  const delayClass = `d${(index % 4) + 1}`;
  el.classList.add(delayClass);
    console.log('added delay class');
});

const io = new IntersectionObserver((entries) => {
     console.log('entered in observer');
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      io.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.12
});

revealEls.forEach(el => io.observe(el));



// Mobile Mega Menu --- Header

document.querySelectorAll(".has-mega > .nav-link").forEach(link=>{

    link.addEventListener("click",function(e){

        if(window.innerWidth>=1024) return;

        e.preventDefault();

        document.querySelectorAll(".has-mega").forEach(item=>{

            if(item!==this.parentElement){
                item.classList.remove("active");
            }

        });

        this.parentElement.classList.toggle("active");

    });

});

// Remove active class on resize

window.addEventListener("resize",()=>{

    if(window.innerWidth>=1024){

        document.querySelectorAll(".has-mega").forEach(item=>{
            item.classList.remove("active");
        });

    }

});

// header-scroll part for class
(function (Drupal) {
  Drupal.behaviors.headerScroll = {
    attach: function (context) {

      const header = document.querySelector('.header');

      if (!header || header.dataset.scrollInit) {
        return;
      }

      header.dataset.scrollInit = true;

      const toggleHeader = () => {
        if (window.scrollY > 20) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }
      };

      toggleHeader(); // Apply immediately on page load

      window.addEventListener('scroll', toggleHeader);
    }
  };
})(Drupal);


jQuery(document).ready(function ($) {

  /*
   * GENERAL SLICK COUNTER
   * (Exclude Platforms & Accelerators) as it was overwriting the counter
   *  */
  $('.slick__slider')
     .not('.slick--view--platforms-and-accelerators .slick__slider')
     .each(function () {

      var $slider = $(this);

      function updateCounter(slick, currentSlide) {

        if (!slick) {
          slick = $slider.slick('getSlick');
        }

        if (!slick) {
          return;
        }

        currentSlide = (currentSlide !== undefined)
          ? currentSlide
          : slick.currentSlide;

        var current = currentSlide + 1;

        var $controls = $slider
          .siblings('.slick__arrow')
          .find('.slider-controls');

        $controls.find('.slider-current').text(
          String(current).padStart(2, '0')
        );

        $controls.find('.slider-total').text(
          String(slick.slideCount).padStart(2, '0')
        );
      }

      if ($slider.hasClass('slick-initialized')) {
        updateCounter();
      }

      $slider.on('afterChange', function (event, slick, currentSlide) {
        updateCounter(slick, currentSlide);
      });

  });

  //General code for carousels - used in platforms,awards,press and news
  (function ($) {

  var sliderConfig = {
    '.slick--view--awards .slick__slider': 4,
    '.slick--view--platforms-and-accelerators .slick__slider': 3,
    '.slick--view--press-release .slick__slider': 3,
    '.slick--view--in-the-news .slick__slider': 2
  };

  $.each(sliderConfig, function (selector, maxCards) {

    $(selector).each(function () {

      var $slider = $(this);

      function updateCounter() {

        if (!$slider.hasClass('slick-initialized')) {
          return;
        }

        var slick = $slider.slick('getSlick');

        if (!slick) {
          return;
        }


        var cardsPerPage = slick.options.slidesToShow || maxCards;

        var currentPage =
          Math.floor(slick.currentSlide / cardsPerPage) + 1;

        var totalPages =
          Math.ceil(slick.slideCount / cardsPerPage);

        var $controls = $slider
          .siblings('.slick__arrow')
          .find('.slider-controls');

        $controls.find('.slider-current').text(
          ('0' + currentPage).slice(-2)
        );

        $controls.find('.slider-total').text(
          ('0' + totalPages).slice(-2)
        );

        $controls.find('.slider-counter').toggle(totalPages !== 1);
      }

      // Remove duplicate handlers
      $slider.off('.sliderCounter');

      // Initial load
      setTimeout(updateCounter, 100);

      // Slick events
      $slider.on(
        'init.sliderCounter reInit.sliderCounter breakpoint.sliderCounter afterChange.sliderCounter',
        function () {
          setTimeout(updateCounter, 50);
        }
      );

      // Window resize
      $(window).off('resize.sliderCounter').on(
        'resize.sliderCounter',
        function () {
          setTimeout(updateCounter, 150);
        }
      );

    });

  });

})(jQuery);

 // Counter for customer success section
 $('.slick--view--success-story-view .slick__slider').each(function () {

  var $slider = $(this);

  function updateCounter(slick, currentSlide) {

    currentSlide = currentSlide !== undefined
      ? currentSlide
      : slick.currentSlide;

    var $controls = $slider
      .siblings('.slick__arrow')
      .find('.slider-controls');

    $controls.find('.slider-current').text(
      String(currentSlide + 1).padStart(2, '0')
    );

    $controls.find('.slider-total').text(
      String(slick.slideCount).padStart(2, '0')
    );
  }

  var slick = $slider.slick('getSlick');

  if (slick) {
    updateCounter(slick);
  }

  $slider.on('afterChange', function (event, slick, currentSlide) {
    updateCounter(slick, currentSlide);
  });

 });


// Overlay

const menu=document.getElementById("mainMenu");
const overlay=document.querySelector(".menu-overlay");

menu.addEventListener("shown.bs.collapse",()=>{

    overlay.classList.add("show");

});

menu.addEventListener("hidden.bs.collapse",()=>{

    overlay.classList.remove("show");

});

overlay.addEventListener("click",()=>{

    const collapse=bootstrap.Collapse.getInstance(menu);

    if(collapse){
        collapse.hide();
    }

});


// document.querySelectorAll('.insights_announcement .field--name-field-description').forEach(el => {
//   el.innerHTML = el.innerHTML
//   .replace(/\bCybage\b/,'<span>Cybage</span>')
//   .replace(
//     /\bAneesh Nathani, VP\b/,
//     '<span>Aneesh Nathani, VP</span>'
//   );

// });


const el = document.querySelector('.insights_announcement .field--name-field-cards .field__item:first-child .field--name-field-description');

if (el) {
  el.innerHTML = el.innerHTML
    .replace(/\bCybage\b/, '<span>Cybage</span>')
    .replace(/Aneesh Nathani, VP/, '<span>Aneesh Nathani, VP</span>');
}

const e2 = document.querySelector('.insights_announcement .field--name-field-cards .field__item:nth-child(2) .field--name-field-description');

if (e2) {
  e2.innerHTML = e2.innerHTML.replace(/Aneesh Nathani, VP/, '<span>Aneesh Nathani, VP</span>');
}
});

(function (Drupal) {
  Drupal.behaviors.serviceContentReveal = {
    attach: function (context) {
      const targets = context.querySelectorAll(
         `.culture-in-motion .title_cards,.title_cards .field--name-field-cards .field__item ,
        .description_link .field--name-field__formatted-title,
        .description_link .field--name-field-link div a ,
        .description_link .field--name-field-description-formatted p,
        .industry-banner .tit-con-wrapper .title .field--name-field__formatted-title,
        .industry-banner .tit-con-wrapper .content,.block-system-breadcrumb-block nav,
        .cta-content .field--name-field-eyebrow-title,.cta-content .field--name-field-title,
        .cta-content .field--name-field-description, .cta-content .field--name-field-link div a,
        .contact-us-banner .field--name-field__formatted-title,
        .contact-us-banner .field--name-field-description-formatted p,
        .hiring-section .heading .field--name-field-eyebrow-title,
        .hiring-section .heading .field--name-field__formatted-title,
        .hiring-section .main-content .image-wrapper,
        .hiring-section .description h2:nth-of-type(1),
        .hiring-section .description h2:nth-of-type(2),
        .hiring-section .description p, .hiring-section .description .field--name-field-link,
        .cyb-contact-us-main .contact-us-img-box .contactus-sub-title,
        .cyb-contact-us-main .contact-us-img-box .contactus-title,
        .cyb-contact-us-main .contact-us-img-box .field--type-image,
        .cyb-contact-us-main .contact-us-web-form-box,
        .main-container .field--name-field-formatted-eyebrow-title,
        .main-container .field--name-field-title-formatted,
        .our-presence-header, .our-presence-container .our-presence-addresses,
        .our-presence-container .our-presence-map,
        .contact-us .contact-us-img-box .contact-description h2,
        .contact-us .contact-us-img-box .contact-description p,
        .contact-us .contact-us-img-box .contact-description .contact-details h4,
        .contact-us .contact-us-img-box .contact-description .contact-details .phone,
        .contact-us .contact-us-img-box .contact-description .contact-details .email,
        .leadership-banner .container-custom .field--name-field__formatted-title,
        .leadership-banner .container-custom .field--name-field-description-formatted p,
        .leadership-banner .container-custom .field--name-field-link div a,
        .announcement-section .split-section-wrapper,
        .industries-landing-banner div.field--name-field__formatted-title ,
        .industries-landing-banner h3,
        .industries-landing-banner p ,
        .blog-banner .tit-con-wrapper .title .text-formatted,
        .blog-banner .tit-con-wrapper .content .field p  ,
        .ceo-desk   .ceo-content  .field--name-field__formatted-title ,
        .ceo-desk   .ceo-content  .field--name-field-description-formatted p,
        .ceo-desk   .ceo-content .field--name-field-link a ,
        .ceo-desk  .ceo-image,
        .contact-us-service .contact-form-service .contact-block .contact-us-img-box .contact-description p,
        .argo-section-1 .field--name-field__formatted-title,
        .argo-section-1 .argo-mini-desc,
        .argo-section-2 .argo-mini-title,
        .argo-section-2 p,
        .argo-platform-architecture .field--name-field__formatted-title,
        .argo-platform-architecture .argo-mini-desc,
        .argo-platform-architecture .argo-mini-title,
        .argo-platform-architecture .description p iframe,
        .why-join-cyb-banner .container-custom .field--name-field__formatted-title,
        .why-join-cyb-banner .container-custom .field--name-field-description-formatted p,
        .why-join-cyb-banner .container-custom .field--name-field-link div a 
        .ceo-desk-banner .field--name-field__formatted-title,
        .ceo-desk-page .container-custom .row .main-content .description .ceo-content .ceo-desc p,
        .ceo-desk-page .container-custom .row .main-content .description .ceo-content .ceo-sign p,
        .ceo-desk-page .container-custom .row .main-content .description .ceo-content .ceo-desk-hr,
        .ceo-desk-page .container-custom .row .main-content .description .ceo-content .ceo-desk-social,
        .aihub-stats-counter div.field--name-field-formatted-eyebrow-title,
        .view-insights-blogs .view-filters,
        .view-insights-blogs .view-content,
        .view-insights-blogs .js-pager__items.pager,
        .announcement-section .eyebrow-ai-announce,
        .view-insights-blogs .view-header`
      );
      if (!targets.length) return;

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.2 });

      targets.forEach((el) => observer.observe(el));
    }
  };
})(Drupal);




jQuery(document).ready(function ($) {

  $('.slick__slider').each(function () {

    var $slider = $(this);

    function updateCounter(slick, currentSlide) {
      var current = (currentSlide !== undefined ? currentSlide : slick.currentSlide) + 1;

      // Find the counter belonging to THIS slider only.
      var $controls = $slider
        .siblings('.slick__arrow')
        .find('.slider-controls');

      $controls.find('.slider-current').text(
        String(current).padStart(2, '0')
      );

      $controls.find('.slider-total').text(
        String(slick.slideCount).padStart(2, '0')
      );
    }

    // Slick is already initialized by Drupal.
    var slick = $slider.slick('getSlick');

    if (slick) {
      updateCounter(slick);
    }

    // Update only this slider's counter when it changes.
    $slider.on('afterChange', function (event, slick, currentSlide) {
      updateCounter(slick, currentSlide);
    });

  });

  // Counter for platform section
  $('.slick--view--platforms-and-accelerators .slick__slider , .slick--view--analyst-recognitions .slick__slider').each(function () {

    var $slider = $(this);

    function updateCounter(slick, currentSlide) {

      currentSlide = (currentSlide !== undefined)
        ? currentSlide
        : slick.currentSlide;

      var slidesToScroll = slick.options.slidesToScroll || 1;

      // Page number (01, 02, 03...)
      var currentPage = Math.floor(currentSlide / slidesToScroll) + 1;

      // Total pages
      var totalPages = Math.ceil(slick.slideCount / slidesToScroll);

      var $controls = $slider
        .siblings('.slick__arrow')
        .find('.slider-controls');

      $controls.find('.slider-current').text(
        String(currentPage).padStart(2, '0')
      );

      $controls.find('.slider-total').text(
        String(totalPages).padStart(2, '0')
      );
    }

    var slick = $slider.slick('getSlick');

    if (slick) {
      updateCounter(slick);
    }

    $slider.on('afterChange', function (event, slick, currentSlide) {
      updateCounter(slick, currentSlide);
    });

  });


});

//active class for industry section
(function ($, Drupal, once) {

  Drupal.behaviors.industryNav = {
    attach: function (context) {

      // Set first nav item active
      once("industry-nav-init", ".industry-nav-list .nav-item", context)
        .forEach(function (element, index) {
          if (index === 0) {
            $(element).addClass("active");
          }
        });

      // Handle click
      once("industry-nav-click", ".industry-nav-list .nav-item", context)
        .forEach(function (element) {

          $(element).on("click", function (e) {

            e.preventDefault();

            console.log("Clicked:", $(this).attr("id"));

            // Remove active from nav items
            $(".industry-nav-list .nav-item").removeClass("active");

            // Add active to clicked nav item
            $(this).addClass("active");

            // Get card ID from href
            var cardId = $(this).find(".nav-anchor-link").attr("href");

            console.log("Target card:", cardId);

            // Remove active from all cards
            $(".industry-card").removeClass("active");

            // Add active to matching card
            $(cardId).addClass("active");

          });

        });

    }
  };

})(jQuery, Drupal, once);


// stats section for counter part and also media stats
// document.addEventListener("DOMContentLoaded", () => {

//     const counters = document.querySelectorAll(".counter-hook");

//     if (!counters.length) return;

//     const observer = new IntersectionObserver((entries, observer) => {

//         entries.forEach(entry => {

//             if (!entry.isIntersecting) return;

//             const counter = entry.target;

//             // Prevent running twice
//             if (counter.dataset.animated) return;
//             counter.dataset.animated = "true";

//             // -----------------------------
//             // Read target & suffix
//             // -----------------------------

//             let target;
//             let suffix;

//             if (counter.dataset.target) {
//                 target = parseFloat(counter.dataset.target);
//                 suffix = counter.dataset.suffix || "";
//             } else {
//                 const text = counter.textContent.trim();

//                 target = parseFloat(text.replace(/[^0-9.]/g, ""));
//                 suffix = text.replace(/[0-9.]/g, "");
//             }

//             if (isNaN(target)) {
//                 observer.unobserve(counter);
//                 return;
//             }

//             // -----------------------------
//             // Random starting value
//             // -----------------------------

//             let start;

//             if (target <= 5) {
//                 start = 0;
//             } else {
//                 start = Math.floor(target * (0.3 + Math.random() * 0.3));
//             }

//             let current = start;

//             const duration = 1500;
//             const fps = 60;
//             const totalFrames = duration / (1000 / fps);
//             const increment = Math.max((target - start) / totalFrames, 0.1);

//             // -----------------------------
//             // Counter animation
//             // -----------------------------

//             function animate() {

//                 current += increment;

//                 if (current >= target) {
//                     current = target;
//                 }

//                 let value;

//                 if (Number.isInteger(target)) {
//                     value = Math.floor(current);
//                 } else {
//                     value = current.toFixed(1);
//                 }

//                 counter.textContent = value + suffix;

//                 if (current < target) {
//                     requestAnimationFrame(animate);
//                 } else {
//                     counter.textContent = target + suffix;
//                     observer.unobserve(counter);
//                 }
//             }

//             requestAnimationFrame(animate);

//         });

//     }, {
//         threshold: 0.4
//     });

//     counters.forEach(counter => observer.observe(counter));

// });

// jQuery(document).on(
//     'input change',
//     'form.webform-submission-contact-form input[required], form.webform-submission-contact-form textarea[required]',
//     function () {

//         const $field = jQuery(this);
//         const $wrapper = $field.closest('.js-form-item');
//         const $error = $wrapper.find('.form-item--error-message');

//         let isValid;

//         // Checkbox
//         if ($field.is(':checkbox')) {

//             isValid = $field.is(':checked');

//         } else {

//             isValid = ($field.val() || '').trim() !== '';
//         }


//         /*
//          * FIELD HAS VALUE
//          */
//         if (isValid) {

//             $field
//                 .removeClass('error is-invalid')
//                 .attr('aria-invalid', 'false');

//             $wrapper
//                 .removeClass('has-error');

//             $error.hide();

//         }


//         /*
//          * FIELD IS EMPTY
//          */
//         else {

//             const requiredMessages = {
//                 name: 'Name field is required.',
//                 job_title: 'Job title field is required.',
//                 work_email: 'WORK EMAIL ID field is required.',
//                 message: 'MESSAGE field is required.',
//                 agree_to_the_privacy_policy:
//                     'You must read and agree to the Privacy Policy in order to proceed.'
//             };

//             const requiredMessage =
//                 requiredMessages[$field.attr('name')] ||
//                 'This field is required.';


//             $field
//                 .addClass('error is-invalid')
//                 .attr('aria-invalid', 'true');

//             $wrapper
//                 .addClass('has-error');


//             /*
//              * IMPORTANT:
//              * Replace the old validation message
//              * with the required message.
//              */
//             $wrapper
//                 .find('.form-item--error-message')
//                 .text(requiredMessage)
//                 .show();
//         }
//     }
// );

// (function ($) {

//     function validateFormat($field) {

//         const $wrapper = $field.closest('.js-form-item');
//         const $error = $wrapper.find('.form-item--error-message');

//         const value = ($field.val() || '').trim();
//         const fieldName = $field.attr('name');


//         /*
//          * IMPORTANT:
//          * Empty fields are handled by your existing
//          * required-field code.
//          */
//         if (value === '') {
//             return;
//         }


//         /*
//          * ==========================================
//          * NAME
//          * ==========================================
//          */
//         if (fieldName === 'name') {

//             /*
//              * Name can contain letters and spaces only.
//              */
//             const namePattern =
//                 /^[A-Za-z]+(?: [A-Za-z]+)*$/;

//             if (!namePattern.test(value)) {

//                 showError(
//                     $field,
//                     $wrapper,
//                     $error,
//                     'Name field is not in the right format.'
//                 );

//                 return;
//             }
//         }


//         /*
//          * ==========================================
//          * JOB TITLE
//          * ==========================================
//          */
//         if (fieldName === 'job_title') {

//             /*
//              * Job title can contain letters and spaces only.
//              */
//             const jobPattern =
//                 /^[A-Za-z]+(?: [A-Za-z]+)*$/;

//             if (!jobPattern.test(value)) {

//                 showError(
//                     $field,
//                     $wrapper,
//                     $error,
//                     'Job title field is not in the right format.'
//                 );

//                 return;
//             }
//         }


//         /*
//          * ==========================================
//          * MESSAGE
//          * ==========================================
//          */
//         if (fieldName === 'message') {

//             /*
//              * Must contain at least ONE letter or number.
//              *
//              * This rejects:
//              * "     "
//              * "@@@@@"
//              * "!!!!!"
//              * "###"
//              * "@#$%"
//              *
//              * But allows:
//              * "Hello"
//              * "Hello world!"
//              * "Hello @ Cybage"
//              * "Test 123"
//              */
//             const hasLetterOrNumber =
//                 /[A-Za-z0-9]/.test(value);

//             if (!hasLetterOrNumber) {

//                 showError(
//                     $field,
//                     $wrapper,
//                     $error,
//                     'Message cannot contain only spaces or special characters. Please enter a valid message.'
//                 );

//                 return;
//             }
//         }


//         /*
//          * ==========================================
//          * WORK EMAIL
//          * ==========================================
//          */
//         if (fieldName === 'work_email') {

//             const emailPattern =
//                 /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

//             if (!emailPattern.test(value)) {

//                 showError(
//                     $field,
//                     $wrapper,
//                     $error,
//                     'Please enter a valid email address.'
//                 );

//                 return;
//             }


//             /*
//              * Check relationship.
//              */
//             const relationship =
//                 $field
//                     .closest('form')
//                     .find(
//                         'select[name="relationship_with_cybage"]'
//                     )
//                     .val();


//             /*
//              * Partner / New Business
//              */
//             if (
//                 relationship === 'partner' ||
//                 relationship ===
//                 'new_business_opportunities_customer'
//             ) {

//                 const personalDomains = [
//                     'gmail.com',
//                     'yahoo.com',
//                     'yahoo.co.in',
//                     'hotmail.com',
//                     'outlook.com',
//                     'live.com',
//                     'msn.com',
//                     'icloud.com',
//                     'me.com',
//                     'aol.com',
//                     'protonmail.com',
//                     'proton.me',
//                     'zoho.com',
//                     'rediffmail.com'
//                 ];

//                 const parts = value.split('@');

//                 const domain =
//                     parts.length > 1
//                         ? parts[1].toLowerCase()
//                         : '';

//                 if (
//                     personalDomains.includes(domain)
//                 ) {

//                     showError(
//                         $field,
//                         $wrapper,
//                         $error,
//                         'Please enter your business email address.'
//                     );

//                     return;
//                 }
//             }
//         }


//         /*
//          * Everything is valid.
//          */
//         $field
//             .removeClass('error is-invalid')
//             .attr('aria-invalid', 'false');

//         $wrapper.removeClass('has-error');

//         $error.hide();
//     }


//     /*
//      * SHOW ERROR
//      */
//     function showError(
//         $field,
//         $wrapper,
//         $error,
//         message
//     ) {

//         $field
//             .addClass('error is-invalid')
//             .attr('aria-invalid', 'true');

//         $wrapper.addClass('has-error');

//         /*
//          * Make sure error element exists.
//          */
//         let $message = $wrapper.find(
//             '.form-item--error-message'
//         );

//         if (!$message.length) {

//             $message = $(
//                 '<div class="invalid-feedback form-item--error-message"></div>'
//             );

//             $wrapper.append($message);
//         }

//         $message
//             .text(message)
//             .show();
//     }


//     /*
//      * INPUT
//      */
//     $(document).on(
//         'input',
//         'form.webform-submission-contact-form input, form.webform-submission-contact-form textarea',
//         function () {

//             validateFormat($(this));
//         }
//     );


//     /*
//      * RELATIONSHIP CHANGE
//      */
//     $(document).on(
//         'change',
//         'form.webform-submission-contact-form select[name="relationship_with_cybage"]',
//         function () {

//             const $form = $(this).closest('form');

//             const $email =
//                 $form.find(
//                     'input[name="work_email"]'
//                 );

//             if ($email.length) {

//                 validateFormat($email);
//             }
//         }
//     );

// })(jQuery);


(function ($) {

    const formSelector =
        'form.webform-submission-contact-form';


    /*
     * ==========================================
     * VALIDATION STATE
     * ==========================================
     */

    let hasSubmitted = false;


    /*
     * ==========================================
     * REQUIRED MESSAGES
     * ==========================================
     */

    const requiredMessages = {

        name:
            'NAME field is required.',

        job_title:
            'JOB TITLE field is required.',

        work_email:
            'WORK EMAIL ID field is required.',

        message:
            'MESSAGE field is required.',

        agree_to_the_privacy_policy:
            'You must read and agree to the Privacy Policy in order to proceed.'
    };


    /*
     * ==========================================
     * MESSAGE ERROR
     * ==========================================
     */

    const messageError =
        'Message cannot contain only spaces or special characters. Please enter a valid message.';


    /*
     * ==========================================
     * SHOW ERROR
     * ==========================================
     */

    function showError($field, message) {

        const $wrapper =
            $field.closest('.js-form-item');


        /*
         * Find existing error messages.
         */

        let $errors =
            $wrapper.find('.form-item--error-message');


        /*
         * Remove duplicate error messages.
         */

        if ($errors.length > 1) {

            $errors
                .slice(1)
                .remove();

            $errors =
                $wrapper.find('.form-item--error-message');
        }


        /*
         * Create error if it doesn't exist.
         */

        if (!$errors.length) {

            $errors = $(
                '<div class="invalid-feedback form-item--error-message"></div>'
            );

            $wrapper.append($errors);
        }


        /*
         * Mark field invalid.
         */

        $field
            .addClass('error is-invalid')
            .attr('aria-invalid', 'true');


        $wrapper
            .addClass('has-error');


        /*
         * Show only one message.
         */

        $errors
            .first()
            .text(message)
            .show();
    }


    /*
     * ==========================================
     * CLEAR ERROR
     * ==========================================
     */

    function clearError($field) {

        const $wrapper =
            $field.closest('.js-form-item');


        $field
            .removeClass('error is-invalid')
            .attr('aria-invalid', 'false');


        $wrapper
            .removeClass('has-error');


        $wrapper
            .find('.form-item--error-message')
            .hide();
    }


    /*
     * ==========================================
     * REQUIRED VALIDATION
     * ==========================================
     */

    function checkRequired($field) {

        const fieldName =
            $field.attr('name');


        /*
         * ======================================
         * CHECKBOX
         * ======================================
         */

        if ($field.is(':checkbox')) {

            if (!$field.is(':checked')) {

                showError(
                    $field,
                    requiredMessages[fieldName] ||
                    'This field is required.'
                );

                return false;
            }

            return true;
        }


        /*
         * ======================================
         * MESSAGE FIELD
         * ======================================
         *
         * IMPORTANT:
         *
         * Empty string:
         *     ""
         *     -> required message
         *
         * Spaces:
         *     "   "
         *     -> handled by checkFormat()
         *        and gets messageError
         */

        if (fieldName === 'message') {

            const rawValue =
                $field.val() || '';


            /*
             * Truly empty.
             */

            if (rawValue === '') {

                showError(
                    $field,
                    requiredMessages.message
                );

                return false;
            }


            /*
             * Anything else is passed to
             * format validation.
             */

            return true;
        }


        /*
         * ======================================
         * ALL OTHER FIELDS
         * ======================================
         */

        const value =
            ($field.val() || '').trim();


        if (value === '') {

            showError(
                $field,
                requiredMessages[fieldName] ||
                'This field is required.'
            );

            return false;
        }


        return true;
    }


    /*
     * ==========================================
     * FORMAT VALIDATION
     * ==========================================
     */

    function checkFormat($field) {

        const fieldName =
            $field.attr('name');


        const rawValue =
            $field.val() || '';


        const value =
            rawValue.trim();


        /*
         * ======================================
         * NAME
         * ======================================
         */

        if (fieldName === 'name') {

            if (value === '') {

                return true;
            }


            const namePattern =
                /^[A-Za-z]+(?: [A-Za-z]+)*$/;


            if (!namePattern.test(value)) {

                showError(
                    $field,
                    'Name field is not in the right format.'
                );

                return false;
            }
        }


        /*
         * ======================================
         * JOB TITLE
         * ======================================
         */

        if (fieldName === 'job_title') {

            if (value === '') {

                return true;
            }


            const jobPattern =
                /^[A-Za-z]+(?: [A-Za-z]+)*$/;


            if (!jobPattern.test(value)) {

                showError(
                    $field,
                    'Job title field is not in the right format.'
                );

                return false;
            }
        }


        /*
         * ======================================
         * MESSAGE
         * ======================================
         *
         * Allowed:
         *
         * A-Z
         * a-z
         * 0-9
         * spaces
         * @
         * !
         * &
         * +
         * -
         */

        if (fieldName === 'message') {

            /*
             * Completely empty is handled
             * by checkRequired().
             */

            if (rawValue === '') {

                return true;
            }


            /*
             * ONLY SPACES
             *
             * Example:
             *
             * " "
             * "   "
             * "     "
             *
             * These get the special-character
             * validation message.
             */

            if (rawValue.trim() === '') {

                showError(
                    $field,
                    messageError
                );

                return false;
            }


            /*
             * MUST CONTAIN LETTER OR NUMBER
             *
             * Examples:
             *
             * @@@
             * !!!
             * &&&
             * +++
             * ---
             *
             * are invalid.
             */

            if (!/[A-Za-z0-9]/.test(rawValue)) {

                showError(
                    $field,
                    messageError
                );

                return false;
            }


            /*
             * ONLY THESE CHARACTERS ARE ALLOWED:
             *
             * Letters
             * Numbers
             * Spaces
             * @
             * !
             * &
             * +
             * -
             */

            const messagePattern =
                /^[A-Za-z0-9\s@!&+\-]+$/;


            /*
             * Reject other special characters.
             */

            if (!messagePattern.test(rawValue)) {

                showError(
                    $field,
                    messageError
                );

                return false;
            }
        }


        /*
         * ======================================
         * WORK EMAIL
         * ======================================
         */

        if (fieldName === 'work_email') {

            /*
             * Empty value is handled by
             * checkRequired().
             */

            if (value === '') {

                return true;
            }


            /*
             * Basic email format.
             */

            const emailPattern =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


            if (!emailPattern.test(value)) {

                showError(
                    $field,
                    'Please enter a valid email address.'
                );

                return false;
            }


            /*
             * Get relationship.
             */

            const relationship =
                $field
                    .closest('form')
                    .find(
                        'select[name="relationship_with_cybage"]'
                    )
                    .val();


            /*
             * Partner / New Business.
             */

            if (
                relationship === 'partner' ||
                relationship ===
                'new_business_opportunities_customer'
            ) {

                const personalDomains = [

                    'gmail.com',
                    'yahoo.com',
                    'yahoo.co.in',
                    'hotmail.com',
                    'outlook.com',
                    'live.com',
                    'msn.com',
                    'icloud.com',
                    'me.com',
                    'aol.com',
                    'protonmail.com',
                    'proton.me',
                    'zoho.com',
                    'rediffmail.com'

                ];


                const parts =
                    value.split('@');


                const domain =
                    parts.length > 1
                        ? parts[1].toLowerCase()
                        : '';


                /*
                 * Personal email domain.
                 */

                if (
                    personalDomains.includes(domain)
                ) {

                    showError(
                        $field,
                        'Please enter your business email address.'
                    );

                    return false;
                }
            }
        }


        return true;
    }


    /*
     * ==========================================
     * VALIDATE ONE FIELD
     * ==========================================
     */

    function validateField($field) {

        /*
         * Required validation first.
         */

        if (!checkRequired($field)) {

            return false;
        }


        /*
         * Format validation second.
         */

        if (!checkFormat($field)) {

            return false;
        }


        /*
         * Everything is valid.
         */

        clearError($field);

        return true;
    }


    /*
     * ==========================================
     * VALIDATE COMPLETE FORM
     * ==========================================
     */

    function validateForm($form) {

        let formValid = true;


        $form
            .find(
                'input[required], textarea[required]'
            )
            .each(function () {

                const $field =
                    $(this);


                if (!validateField($field)) {

                    formValid = false;
                }

            });


        return formValid;
    }


    /*
     * ==========================================
     * SUBMIT BUTTON
     * ==========================================
     *
     * Capture phase is important because
     * Drupal Webform AJAX also has its own
     * submit handling.
     */

    document.addEventListener(
        'click',
        function (event) {

            const submitButton =
                event.target.closest(
                    formSelector +
                    ' input[type="submit"], ' +
                    formSelector +
                    ' button[type="submit"]'
                );


            /*
             * Not our submit button.
             */

            if (!submitButton) {

                return;
            }


            const form =
                submitButton.closest(
                    'form.webform-submission-contact-form'
                );


            if (!form) {

                return;
            }


            const $form =
                $(form);


            /*
             * Enable live validation after
             * first submit attempt.
             */

            hasSubmitted = true;


            /*
             * Disable browser native validation.
             */

            form.setAttribute(
                'novalidate',
                'novalidate'
            );


            /*
             * Validate complete form.
             */

            const valid =
                validateForm($form);


            /*
             * ==================================
             * INVALID
             * ==================================
             */

            if (!valid) {

                event.preventDefault();

                event.stopPropagation();

                event.stopImmediatePropagation();


                /*
                 * Focus first invalid field.
                 */

                const firstInvalid =
                    form.querySelector(
                        '.is-invalid'
                    );


                if (firstInvalid) {

                    setTimeout(function () {

                        firstInvalid.focus();

                    }, 50);
                }


                return false;
            }


            /*
             * ==================================
             * VALID
             * ==================================
             *
             * Allow Drupal AJAX to continue.
             */

        },
        true
    );


    /*
     * ==========================================
     * LIVE VALIDATION AFTER FIRST SUBMIT
     * ==========================================
     */

    $(document).on(
        'input.customContactValidation',
        formSelector +
        ' input, ' +
        formSelector +
        ' textarea',
        function () {

            /*
             * ==================================
             * MESSAGE 500 CHARACTER LIMIT
             * ==================================
             */

            if (
                $(this).attr('name') === 'message' &&
                this.value.length > 500
            ) {

                this.value =
                    this.value.substring(
                        0,
                        500
                    );
            }


            /*
             * Do nothing before first submit.
             */

            if (!hasSubmitted) {

                return;
            }


            /*
             * Validate current field.
             */

            validateField(
                $(this)
            );
        }
    );


    /*
     * ==========================================
     * RELATIONSHIP CHANGE
     * ==========================================
     */

    $(document).on(
        'change.customContactValidation',
        formSelector +
        ' select[name="relationship_with_cybage"]',
        function () {

            if (!hasSubmitted) {

                return;
            }


            const $form =
                $(this).closest('form');


            const $email =
                $form.find(
                    'input[name="work_email"]'
                );


            if ($email.length) {

                validateField(
                    $email
                );
            }
        }
    );


    /*
     * ==========================================
     * MESSAGE PASTE LIMIT
     * ==========================================
     *
     * Prevent more than 500 characters
     * from being pasted.
     */

    document.addEventListener(
        'paste',
        function (event) {

            const textarea =
                event.target.closest(
                    formSelector +
                    ' textarea[name="message"]'
                );


            /*
             * Not the Message field.
             */

            if (!textarea) {

                return;
            }


            const clipboard =
                event.clipboardData ||
                window.clipboardData;


            if (!clipboard) {

                return;
            }


            const pastedText =
                clipboard.getData('text');


            const currentValue =
                textarea.value;


            const start =
                textarea.selectionStart;


            const end =
                textarea.selectionEnd;


            /*
             * Calculate current length after
             * replacing selected text.
             */

            const currentLength =
                currentValue.length -
                (end - start);


            /*
             * Characters still available.
             */

            const available =
                500 -
                currentLength;


            /*
             * Already at 500.
             */

            if (available <= 0) {

                event.preventDefault();

                return;
            }


            /*
             * Pasted text fits.
             */

            if (
                pastedText.length <= available
            ) {

                return;
            }


            /*
             * Stop normal paste.
             */

            event.preventDefault();


            /*
             * Only insert characters that fit.
             */

            const textToInsert =
                pastedText.substring(
                    0,
                    available
                );


            textarea.setRangeText(
                textToInsert,
                start,
                end,
                'end'
            );


            /*
             * Trigger input event so
             * validation and Drupal counter
             * can update.
             */

            $(textarea).trigger('input');

        },
        true
    );


    /*
     * ==========================================
     * MESSAGE 500 CHARACTER BACKUP
     * ==========================================
     */

    $(document).on(
        'input.messageCharacterLimit',
        formSelector +
        ' textarea[name="message"]',
        function () {

            if (this.value.length > 500) {

                this.value =
                    this.value.substring(
                        0,
                        500
                    );
            }
        }
    );

    //swati's code for dropdown and hover menu overlap issue-ticket id 3991
    $('.nav-item.has-mega').hover(
      function () {
      $('.webform-submission-contact-form select').prop('disabled', true);
      },
      function () {
      $('.webform-submission-contact-form  select').prop('disabled', false);
      }
      );

    $('.custom-our-platform .view-content').removeClass('row');
})(jQuery);


document.addEventListener("DOMContentLoaded", () => {

    const counters = document.querySelectorAll(".counter-hook");

    if (!counters.length) return;

    const observer = new IntersectionObserver((entries, observer) => {

        entries.forEach(entry => {

            if (!entry.isIntersecting) return;

            const counter = entry.target;

            // Prevent running twice
            if (counter.dataset.animated) return;
            counter.dataset.animated = "true";

            // -----------------------------
            // Read target & suffix
            // -----------------------------

            let target;
            let suffix;

            if (counter.dataset.target) {
                target = parseFloat(counter.dataset.target.toString().replace(/,/g, ""));
                suffix = counter.dataset.suffix || "";
            } else {
                const text = counter.textContent.trim();

                // Remove commas before parsing
                target = parseFloat(
                    text.replace(/,/g, "").replace(/[^0-9.]/g, "")
                );

                // Keep any suffix like +, %, etc.
                suffix = text.replace(/[0-9.,]/g, "");
            }

            if (isNaN(target)) {
                observer.unobserve(counter);
                return;
            }

            // -----------------------------
            // Random starting value
            // -----------------------------

            let start;

            if (target <= 5) {
                start = 0;
            } else {
                start = Math.floor(target * (0.3 + Math.random() * 0.3));
            }

            let current = start;

            const duration = 1500;
            const fps = 60;
            const totalFrames = duration / (1000 / fps);
            const increment = Math.max((target - start) / totalFrames, 0.1);

            // -----------------------------
            // Counter animation
            // -----------------------------

            function animate() {

                current += increment;

                if (current >= target) {
                    current = target;
                }

                let value;

                if (Number.isInteger(target)) {
                    value = Math.floor(current).toLocaleString("en-US");
                } else {
                    value = Number(current.toFixed(1)).toLocaleString("en-US", {
                        minimumFractionDigits: 1,
                        maximumFractionDigits: 1
                    });
                }

                counter.textContent = value + suffix;

                if (current < target) {
                    requestAnimationFrame(animate);
                } else {
                    counter.textContent = Number(target).toLocaleString("en-US", {
                        minimumFractionDigits: Number.isInteger(target) ? 0 : 1,
                        maximumFractionDigits: Number.isInteger(target) ? 0 : 1
                    }) + suffix;

                    observer.unobserve(counter);
                }
            }

            requestAnimationFrame(animate);

        });

    }, {
        threshold: 0.4
    });

    counters.forEach(counter => observer.observe(counter));

});
// Keep your existing JS above unchanged.

// Range counter
document.addEventListener("DOMContentLoaded", () => {

    const counters = document.querySelectorAll(".software-hitech-stats .counter-hook");

    if (counters.length < 4) return;

    // 4th counter only
    const counter = counters[3];

    // Prevent the original counter JS from animating this element
    counter.dataset.animated = "true";

    const minTarget = 800;
    const maxTarget = 1200;

    const duration = 1500;
    const startTime = performance.now();

    function animate(currentTime) {

        const progress = Math.min(
            (currentTime - startTime) / duration,
            1
        );

        const minValue = Math.floor(minTarget * progress);
        const maxValue = Math.floor(maxTarget * progress);

        counter.textContent =
            `${minValue.toLocaleString("en-US")}-${maxValue.toLocaleString("en-US")}`;

        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            counter.textContent = "800-1200";
        }
    }

    requestAnimationFrame(animate);

});

// code by Ashwini
document.addEventListener("DOMContentLoaded", () => {
 
    const counters = document.querySelectorAll(
        ".infios-stats .counter-hook"
    );
 
    if (counters.length < 4) return;
 
    const counter = counters[3];
 
    counter.dataset.animated = "true";
 
    const minTarget = 24;
    const maxTarget = 7;
 
    const duration = 1500;
    const startTime = performance.now();
 
    function animate(currentTime) {
 
        const progress = Math.min(
            (currentTime - startTime) / duration,
            1
        );
 
        const minValue = Math.floor(minTarget * progress);
        const maxValue = Math.floor(maxTarget * progress);
 
        counter.textContent = `${minValue}x${maxValue}`;
 
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            counter.textContent = "24x7";
        }
    }
 
    requestAnimationFrame(animate);
 
});
// end of code by Ashwini

(function (Drupal, once) {
  Drupal.behaviors.customBackToTop = {
    attach(context) {
      once('custom-back-to-top', '#backtotop', context).forEach((button) => {
        button.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M5 10L9 6L13 10" stroke="#383228" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path></svg>
        `;
      });
    }
  };
})(Drupal, once);

// blogs - deeksha
(function ($, Drupal) {

  // Listen directly to any global AJAX completion on the document
  $(document).ajaxComplete(function (event, xhr, settings) {
    // 1. Check if the AJAX URL contains your view's path or name
    if (settings.url && (settings.url.indexOf('insights_blogs') !== -1 || settings.url.indexOf('views/ajax') !== -1)) {
      // 2. Target your view container exactly matching the HTML class attribute
      var $view = $('.view-insights-blogs');

      if ($view.length) {
        // 3. Count the Bootstrap column elements inside the grid row wrapper
        var itemsShown = $view.find('.grid.views-view-grid.row > div').length;

        // 4. Target your "SHOWING X OF Y" element inside the view-header
        var $summary = $view.find('.view-header');

        if ($summary.length && itemsShown > 0) {
           var currentText = $summary.text();

           // 5. Replace "SHOWING X" or "showing X" regardless of letter case
           var updatedText = currentText.replace(/(SHOWING|Showing|showing)\s+\d+/, 'SHOWING ' + itemsShown);

           $summary.text(updatedText);
        }
      }
    }
  });

})(jQuery, Drupal);
// end of blogs - deeksha

// featured & announcement
(function ($, Drupal) {
  Drupal.behaviors.forceSectionRedirects = {
    attach: function (context, settings) {
      // Targets all links inside both the featured and announcement sections
      $(context).find('.featured-section a, .announcement-section a').each(function () {
        // Rewrite the href path to point directly to the homepage
        $(this).attr('href', '/');
      });
    }
  };
})(jQuery, Drupal);
// end of feature & announcement

//hiding button for feature section-- Aug release
(function (Drupal) {
  "use strict";

  Drupal.behaviors.insightsFeaturedSectionFix = {
    attach: function (context) {

      // 1. Target the featured section using pure vanilla JS
      const featuredSections = context.querySelectorAll('.insights-featured-section');

      featuredSections.forEach(featuredSection => {

        // 2. Find and hide the pagination controls and slider arrows
        // const controls = featuredSection.querySelectorAll('.slick__arrow, .slider-controls');
        // controls.forEach(element => {
        //   element.style.setProperty('display', 'none', 'important');
        // });

        // 3. Find all view node wrapper field containers inside this section
        const targetFields = featuredSection.querySelectorAll('.views-field.views-field-view-node');

        targetFields.forEach(targetField => {

          // 4. Pure JS Replacement for once(): Check if we already processed this specific container
          if (targetField.getAttribute('data-processed') === 'true') {
            return; // Skip if already processed
          }

          // 5. Find all <a> tags inside this specific container
          const links = targetField.querySelectorAll('a');

          links.forEach(downloadLink => {
            // Clean up the text by removing trailing line breaks/spaces, then lower-case it
            const cleanText = downloadLink.textContent.replace(/\s+/g, ' ').trim().toLowerCase();

            // 6. Check if the link contains the phrase "download pdf"
            if (cleanText.includes('download pdf')) {

              // 7. Find the specific parent span wrapper
              const parentSpan = downloadLink.closest('span.field-content');

              if (parentSpan) {
                // Create the new span element
                const staticPagination = document.createElement('span');
                staticPagination.className = 'static-pagination-display';

                // Apply layout styles for perfect alignment
                staticPagination.style.marginLeft = '12px';
                staticPagination.style.display = 'inline-flex';
                staticPagination.style.alignItems = 'center';
                staticPagination.style.gap = '4px';

                // Set the inner HTML template (SVG + Text)
                staticPagination.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="3" y="1.5" width="8" height="11" rx="1.2" stroke="#636577" stroke-width="1.2"></rect><path d="M4.5 5h5M4.5 7.5h5M4.5 10h3" stroke="#636577" stroke-width="1.2" stroke-linecap="round"></path></svg>18 PAGES';

                // 8. Inject it exactly after the </span> closing tag
                parentSpan.parentNode.insertBefore(staticPagination, parentSpan.nextSibling);

                // 9. Mark this container as processed so it never runs twice
                targetField.setAttribute('data-processed', 'true');
              }
            }
          });
        });
      });
    }
  };
})(Drupal);
// End of hiding button for feature section-- Aug release


// adding code for industry landing page - staking-cards------------

(function (Drupal, once) {
  'use strict';

  Drupal.behaviors.stackingCards = {
    attach: function (context) {

      once('stacking-cards', '.stacking-cards .field--name-field-cards', context).forEach(function (container) {

        const cards = Array.from(
          container.querySelectorAll(':scope > .field__item > .industries-card')
        );

        if (!cards.length) {
          return;
        }

        const stackingOffset = 60;
        let isClickScrolling = false;
        let scrollTimer = null;
        let ticking = false;

        cards.forEach(function (card, index) {
          card.style.setProperty('--index', index);

          const header = card.querySelector('.card-header');

          if (header) {
            header.setAttribute('role', 'button');
            header.setAttribute('tabindex', '0');
            header.setAttribute(
              'aria-label',
              'Navigate to card ' + (index + 1)
            );
            header.setAttribute('aria-expanded', 'true');
          }
        });

        /*
         * IMPORTANT:
         * getBoundingClientRect() is not reliable for a sticky card.
         * Once a card is sticky, rect.top is its current sticky position,
         * not its original document-flow position.
         */
        function getCardScrollPosition(index) {
          const card = cards[index];

          if (!card) {
            return 0;
          }

          const originalPosition = card.style.position;
          const originalTop = card.style.top;

          /*
           * Temporarily measure the clicked card in normal flow.
           */
          card.style.position = 'relative';
          card.style.top = 'auto';

          const rect = card.getBoundingClientRect();
          const documentTop = rect.top + window.scrollY;

          card.style.position = originalPosition;
          card.style.top = originalTop;

          return documentTop - (index + 1) * stackingOffset;
        }

        function setCardState(card, collapsed) {
          const header = card.querySelector('.card-header');

          if (collapsed) {
            card.classList.add('is-docked', 'is-collapsed');

            if (header) {
              header.setAttribute('aria-expanded', 'false');
            }
          }
          else {
            card.classList.remove('is-docked', 'is-collapsed');

            if (header) {
              header.setAttribute('aria-expanded', 'true');
            }
          }
        }

        function updateDockedStates() {
          if (isClickScrolling) {
            return;
          }

          cards.forEach(function (card, index) {
            const next = cards[index + 1];

            /*
             * Last card is always open.
             */
            if (!next) {
              setCardState(card, false);
              return;
            }

            const nextRect = next.getBoundingClientRect();
            const threshold = (index + 2) * stackingOffset;

            setCardState(
              card,
              nextRect.top <= threshold + 5
            );
          });
        }

        function scrollToCard(index) {
          if (index < 0 || index >= cards.length) {
            return;
          }

          isClickScrolling = true;

          /*
           * Previous cards collapse;
           * clicked and following cards open.
           */
          cards.forEach(function (card, i) {
            setCardState(card, i < index);
          });

          /*
           * Measure after the states are set,
           * but before sticky affects the target.
           */
          const target = getCardScrollPosition(index);

          window.scrollTo({
            top: Math.max(0, target),
            behavior: 'smooth'
          });

          clearTimeout(scrollTimer);

          scrollTimer = setTimeout(function () {
            isClickScrolling = false;
            updateDockedStates();
          }, 1800);
        }

        cards.forEach(function (card, index) {
          const header = card.querySelector('.card-header');

          if (!header) {
            return;
          }

          header.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            scrollToCard(index);
          });

          header.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();

              scrollToCard(index);
            }
          });
        });

        window.addEventListener(
          'scroll',
          function () {
            if (ticking) {
              return;
            }

            requestAnimationFrame(function () {
              updateDockedStates();
              ticking = false;
            });

            ticking = true;
          },
          {
            passive: true
          }
        );

        let resizeTimer = null;

        window.addEventListener('resize', function () {
          clearTimeout(resizeTimer);

          resizeTimer = setTimeout(
            updateDockedStates,
            150
          );
        });

        updateDockedStates();

        console.log(
          'Stacking Cards initialized:',
          cards.length,
          'cards'
        );

      });
    }
  };

})(Drupal, once);
// adding code for industry landing page - staking-cards ends------------

//partner images for partner page
(function (Drupal, once) {

  Drupal.behaviors.mergePartnerCards = {

    attach: function (context) {

      once(
        'merge-partner-cards',
        '.our_partners_section_1',
        context
      ).forEach(function (firstSection) {

        if (window.innerWidth > 767) {
          return;
        }

        const sections = document.querySelectorAll(
          '.our_partners_section_1, .our_partners_section_2, .our_partners_section_3'
        );

        const firstCards = firstSection.querySelector(
          '.field--name-field-partner-cards'
        );

        if (!firstCards) {
          return;
        }

        sections.forEach(function (section, index) {

          if (index === 0) {
            return;
          }

          const cards = section.querySelectorAll(
            '.field--name-field-partner-cards > .field__item'
          );

          cards.forEach(function (card) {
            firstCards.appendChild(card);
          });

          section.style.display = 'none';
        });

        firstCards.style.setProperty('display', 'flex', 'important');
        firstCards.style.setProperty('flex-wrap', 'wrap', 'important');
        firstCards.style.setProperty('justify-content', 'flex-start', 'important');
        firstCards.style.setProperty('gap', '12px', 'important');

        firstCards
          .querySelectorAll(':scope > .field__item')
          .forEach(function (card) {

            card.style.setProperty(
              'flex',
              '0 0 calc(50% - 6px)',
              'important'
            );

            card.style.setProperty(
              'width',
              'calc(50% - 6px)',
              'important'
            );

            card.style.setProperty(
              'max-width',
              'calc(50% - 6px)',
              'important'
            );

            card.style.setProperty(
              'margin',
              '0',
              'important'
            );
          });

      });

    }

  };

})(Drupal, once);



// Header Level 3 added submenu heading
const megaRight = document.querySelector(".navbar-nav > .nav-item:nth-child(3) .mega-right");
 
if (megaRight) {
  // Select ONLY anchor tags (ignores any <span> headers in the DOM)
  const links = Array.from(megaRight.querySelectorAll("a"));
 
  // 1. First 2 links go to Platforms (Indexes 0 and 1)
  const platformLinks = links.slice(0, 2);
 
  // 2. Remaining links go to Frameworks (Index 2 onwards)
  const frameworkLinks = links.slice(2);
 
  // Clear existing layout to avoid duplicate nodes
  megaRight.innerHTML = "";
 
  // Build Column 1
  const col1 = document.createElement("div");
  col1.className = "menu-col";
  col1.innerHTML = `<span class="menu-head">PLATFORMS</span>`;
  platformLinks.forEach(link => col1.appendChild(link));
 
  // Build Column 2
  const col2 = document.createElement("div");
  col2.className = "menu-col";
  col2.innerHTML = `<span class="menu-head">FRAMEWORKS</span>`;
  frameworkLinks.forEach(link => col2.appendChild(link));
 
  // Append clean columns
  megaRight.appendChild(col1);
  megaRight.appendChild(col2);
}
