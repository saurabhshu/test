(function (Drupal, once) {

  Drupal.behaviors.heroSlider = {
    attach(context) {

      once('hero-slider', '#videoHeroCarousel', context).forEach(function () {

        // ==========================================================================
        // HERO ENTRANCE CONTROLLER
        // ==========================================================================
        const carousel = document.getElementById('videoHeroCarousel');

        function animate() {
          // Remove animation from all slides
          carousel.querySelectorAll('.hero-interface-wrapper').forEach(wrapper => {
            wrapper.querySelectorAll('h1, p, .hero-actions').forEach(el => {
              el.classList.remove('show');
            });
          });

          const active = carousel.querySelector('.carousel-item.active .hero-interface-wrapper');

          if (!active) return;

          // Add animation only to the active slide
          active.querySelectorAll('h1, p, .hero-actions').forEach(el => {
            el.classList.add('show');
          });
        }


        window.addEventListener('load', animate);
        carousel.addEventListener('slid.bs.carousel', animate);

        // ==========================================================================
        // Slider navbar buttons
        // ==========================================================================

        const carouselEl = document.getElementById('videoHeroCarousel');
        const currentCounter = carouselEl.querySelector('.current');
        const totalCounter = carouselEl.querySelector('.total');

        const slides = carouselEl.querySelectorAll('.carousel-item');

        // Set total slides
        if (totalCounter) {
            totalCounter.textContent = String(slides.length).padStart(2, '0');
        }

        function updateCounter() {
            if (!currentCounter) return;

            const activeIndex = [...slides].findIndex(item =>
                item.classList.contains('active')
            );

            currentCounter.textContent = String(activeIndex + 1).padStart(2, '0');
        }

        // Initial counter
        updateCounter();

        // Update after every slide change
        carouselEl.addEventListener('slid.bs.carousel', updateCounter);

        // ==========================================================================
        // SMOOTH SCROLL DEPTH PARALLAX TRACKING
        // ==========================================================================
        const heroSection = document.getElementById('hero-section');
        const heroParallax = document.getElementById('hero-parallax');

        if (
          heroSection &&
          heroParallax &&
          !window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ) {
          window.addEventListener(
            'scroll',
            () => {
              const rect = heroSection.getBoundingClientRect();

              if (
                rect.bottom > 0 &&
                rect.top <= window.innerHeight
              ) {
                const progress = Math.min(
                  Math.max(-rect.top / rect.height, 0),
                  1
                );

                heroParallax.style.transform =
                  `translateY(${progress * 140}px)`;
              }
            },
            { passive: true }
          );
        }

        // ==========================================================================
        // AUTOPLAY VIDEO BANNER TIMING INTERFACE
        // ==========================================================================

        let carouselInstance = null;
        let progressBar = null;
        let imageTimer = null;

        if (carouselEl) {

          progressBar = carouselEl.querySelector('.carousel-progress-bar');

          carouselInstance = bootstrap.Carousel.getOrCreateInstance(
            carouselEl,
            {
              interval: false,
              ride: false,
              wrap: true
            }
          );

          carouselEl.addEventListener(
            'slide.bs.carousel',
            () => {

              // Clear previous image timer
              clearTimeout(imageTimer);

              if (progressBar) {
                progressBar.style.transition = 'none';
                progressBar.style.width = '0%';
              }

              carouselEl
                .querySelectorAll('.carousel-item video')
                .forEach(video => {
                  video.pause();
                  video.onended = null;
                });
            }
          );

          carouselEl.addEventListener(
            'slid.bs.carousel',
            playActiveVideo
          );

          playActiveVideo();
        }


        function startProgress(duration) {

          if (!progressBar) return;

          const slides = carouselEl.querySelectorAll('.carousel-item');
          const totalSlides = slides.length;

          const activeIndex = [...slides].findIndex(
            slide => slide.classList.contains('active')
          );

          const startWidth = (activeIndex / totalSlides) * 100;
          const endWidth = ((activeIndex + 1) / totalSlides) * 100;

          progressBar.style.transition = 'none';
          progressBar.style.width = startWidth + '%';

          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              progressBar.style.transition = `width ${duration}s linear`;
              progressBar.style.width = endWidth + '%';
            });
          });
        }

        function playActiveVideo() {

          if (!carouselEl || !carouselInstance) return;

          const activeSlide = carouselEl.querySelector('.carousel-item.active');

          if (!activeSlide) return;

          const media = activeSlide.querySelector('.hero-background-video-image');
          if (!media) return;

          const tag = media.tagName.toLowerCase();

          // ================= IMAGE =================
          if (tag === 'img') {

            const imageDuration = 8;

            startProgress(imageDuration);

            const currentSlide = activeSlide;
            clearTimeout(imageTimer);

            imageTimer = setTimeout(() => {
              // Only move if this image is still active
              if (!currentSlide.classList.contains('active')) {
                return;
              }
              carouselInstance.next();
            }, imageDuration * 1000);

            return;
          }

          // ================= VIDEO =================
          if (tag === 'video') {

            const video = media;

            const playVideo = () => {

              // Use actual video duration for progress
              startProgress(video.duration || 6);

              video.play().catch(err => {
                console.log('Video play error:', err);
              });

              const currentSlide = activeSlide;

              video.onended = () => {
                // Prevent old videos triggering next
                if (!currentSlide.classList.contains('active')) {
                  return;
                }
                carouselInstance.next();
              };
            };

            if (video.readyState >= 1) {
              playVideo();
            } else {
              video.addEventListener(
                'loadedmetadata',
                function handler() {
                  playVideo();
                  video.removeEventListener(
                    'loadedmetadata',
                    handler
                  );
                }
              );
            }

            return;
          }
        }

      });

    }
  };

})(Drupal, once);